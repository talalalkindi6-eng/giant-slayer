# Giant Slayer — NeoForge 1.21.1 mod

Grapple gear, nape-only giant kills, massive ring walls, and the open sea: ships, corsairs, power fruits and buried treasure, all tied together in one story.

## Build it
The easiest route (no Gradle setup headaches):
1. Download the official **NeoForge 1.21.1 MDK** (https://neoforged.net → "Mod Developer Kit", or the `MDK-1.21.1-ModDevGradle` template on GitHub).
2. Delete the MDK's `src` folder and copy this project's `src` folder in.
3. In the MDK's `gradle.properties` set `mod_id=giantslayer`, `mod_group_id=com.giantslayer`, `mod_name=Giant Slayer`.
4. Run `gradlew runClient` to test, or `gradlew build` → the jar is in `build/libs/`.
5. Drop the jar into the `mods` folder of a NeoForge 1.21.1 install.

(The included `build.gradle` also works if you add the Gradle wrapper; bump `neo_version` to the latest 21.1.x if it complains.)

## Controls
| Key | Action |
|---|---|
| **R (hold)** | Fire grapple where you look (45 blocks). Hold to reel in, release to let go. Hooks onto blocks **and giants**. |
| **V (hold, airborne)** | Gas boost in the direction you look. |
| **G** | Use your power fruit's ability. |
| **B** | Fire a broadside (while aboard your ship). |
Keys are rebindable under Options → Controls → "Giant Slayer".

## Items
- **Maneuver Gear** — keep it anywhere in your inventory. The blue bar is your gas (600). Also cuts fall damage by 80% while it has gas.
- **Gas Canister** — right-click to refill your gear.
- **Slayer Blade** — hit a giant's nape (behind it, up near its neck) to kill it in one strike. Dulls fast.
- **Wall Charter** — use on the ground: a 40-radius, 24-high ring wall rises around that spot. **Sneak-use** for a 96-radius, 40-high wall. The gate opens toward where you face. Giants never naturally spawn inside your walls.
- **Wall Stone** — near-explosion-proof building block.

## Field Equipment
| Item | What it does | Recipe |
|---|---|---|
| **Thunder Lance** (x2) | Right-click to launch. Sticks into what it hits and explodes 1.5s later (no block damage). Takes ~60% of a giant's health, and **kills instantly if stuck in the nape**. | TNT top-right, iron ingot middle, stick bottom-left (diagonal) |
| **Flare Pistol** | Fires the flare in your offhand (or the first in your inventory). | `I F I / _ P _`: iron, flint & steel, any planks |
| **Green Flare** (x3) | Reveals every giant within 128 blocks (glowing, 20s). | Paper + gunpowder + green dye |
| **Red Flare** (x3) | Lures giants within 96 blocks to where it bursts. | Paper + gunpowder + red dye |
| **Black Flare** (x3) | Smoke screen: giants within 40 blocks lose their target for 8s. | Paper + gunpowder + black dye |
| **Scout Cloak** | Chest armor. While sneaking, giants more than 10 blocks away can't lock onto you. | `W _ W / W L W / W W W`: green wool, leather |
| **Ember Steel Blade** | Diamond-tier slayer blade, much more durable. Still nape-kills. | Slayer blade + 2 diamonds + blaze powder |
| **Scout Ration** (x3) | Hearty food (7 hunger, high saturation). | Bread + cooked beef + apple |
| **Wall Cannon** | Place it facing outward. Right-click with a cannonball to fire where you look. 40% giant health per hit, plus a heavy stagger. | `III / PGP / PPP`: iron blocks, gunpowder, planks |
| **Cannonball** (x4) | Cannon ammo. | Iron ingots in a plus shape around gunpowder |

Watchtower chests can also contain flares, rations, lances and flare pistols.

## Giants
All giants hunt players, villagers and golems. Anything but a nape strike does ~15% damage, and they regenerate in steam. Rare surface spawns, max ~3 per area, never inside your walls, never on Peaceful.

| Type | Size | What it does | How to beat it |
|---|---|---|---|
| **Wanderer** | 6–16 | The standard giant. | Get behind, get high, cut the nape. |
| **Sprinter** | 7–12, lanky | Very fast, frail. Runs down anyone on foot. | Don't run — grapple up and strike from above. |
| **Leaper** | 6–11 | Jumps 10–25 blocks at distant prey, slam on landing knocks you off your lines. | Bait the leap, then hit its nape while it recovers. |
| **Howler** | 8–14 | Roar flings players back, snaps grapple lines, slows + dizzies, and calls every giant within 64 blocks. | Kill it first, before it rallies the others. |
| **Burrower** | 6–12, stocky | Sinks underground (invulnerable), then bursts up beneath you and launches everything. Can't tunnel past walls. | Stay airborne when it vanishes; strike as it emerges. |
| **Brood Mother** | 12–16, hulking | Slow and huge. Splits off 2 small giants every time it loses 25% health. Better loot. | One clean nape kill skips the whole brood. |

## Worldgen
- **Watchtowers** with a ladder and a supply chest (gas, blades, sometimes gear).
- **Ruined wall fragments** scattered across the overworld.

## Recipes
- Maneuver Gear: `I C I / L T L / S _ S` (iron, chain, leather, tripwire hook, string)
- Gas Canister: shapeless iron ingot + gunpowder + glass bottle
- Slayer Blade: iron ingots on a diagonal with a stick at the bottom-left
- Wall Stone ×8: 8 stone bricks around 1 iron ingot
- Wall Charter: 8 wall stone around an empty map

## Story Mode: *The Ember Watch*
You spawn holding the **Ember Watch Journal**. Use it to found the camp where you stand, and the four camp members appear. **Right-click a character to talk.** Dialogue plays on an animated screen with a live portrait, typewriter text and a voice blip for each character. Click, Space or Enter advances it.

**Cast** (each has their own idle animation and gestures while talking):
- **Commander Halvard Reyne**: leader of the Watch. Stands with his hands behind his back.
- **Mira Thale**: scout instructor. Teaches the gear and carries a blade.
- **Old Bram**: smith. Hammers away when idle.
- **Tova**: young lookout. Always scanning the horizon.

**Chapters**
1. Meet Reyne, then get your gear from Mira and complete the grapple drill.
2. Bram forges your blades. Make your first nape kill.
3. Clear three giants from the hills.
4. Tova spots a Howler. Hunt it down.
5. Reyne gives you the Wall Charter. Raise a wall.
6. A Brood Mother approaches. Kill it with one clean cut.
7. Get promoted to Warden, with rewards.

Story giants are spawned near you when a chapter needs them. Use the journal any time to see your objective. If your camp is lost, sneak-use the journal more than 128 blocks from any camp member to re-found it. Progress is saved per player and kept through death. Play on Easy or higher: giants don't exist on Peaceful.


## Seas & Corsairs
**Sloop.** Right-click on water to launch it. It seats 4, and the first to board steers. It's much faster than a boat, and the sail billows as you pick up speed. The pilot presses **B** to fire a broadside: one cannonball from each side, costing 2 cannonballs. Recipe: `W W W / _ L _ / P B P` (white wool, any log, planks, any boat).

**Corsairs** spawn on beaches at night and guard islands. They come in two looks and carry cutlasses or axes. **Captain Morrow Vane, the Storm Corsair**, is the boss. He ate the Galefruit, and he raises his arms to cast:
- **Gale Blast**: flings you back and snaps your grapple.
- **Wind Step**: appears behind you.
- **All Hands**: summons his crew below 60% health.

He has a boss bar and drops the Galefruit, gold and a treasure map.

**Islands** form in oceans with sand, palms and a corsair camp. Two guards watch a chest buried under a red X.

**Treasure Map.** Use it to get a distance and direction to the cache. Within 6 blocks, the cache is unearthed under a red X. Recipe: map + gold ingot + compass (shapeless).

**Cutlass.** A fast iron sword. Recipe: two iron ingots stacked, with a stick at the bottom-left.

## Power Fruits (one per person, forever)
Eat one, then press **G**. Every use plays a colored aura spiral (the fruit-eater animation), and fruit-eaters give off a faint idle aura. Eating a second fruit poisons you.

| Fruit | Ability (G) | Passive | Cooldown |
|---|---|---|---|
| **Galefruit** | Gale Burst: rocket forward, blast nearby foes away | Half fall damage | 4s |
| **Stonehide** | Stone Skin: Resistance III + ground slam | Resistance I | 20s |
| **Thornvine** | Root Snare: pins everything in a 16-block cone | Heal on grass | 15s |
| **Blinkfruit** | Blink: teleport 24 blocks where you look | Night vision | 3s |
| **Tidefruit** | Tidal Wave: hurls enemies back, puts out fire | Breathe + swim fast underwater | 10s |
| **Colossus** | Grow 3x for 15s, with long reach and huge hits. **Big enough to nape-cut giants from the ground.** | Extra health | 45s |

Fruits drop from island and buried treasure, the captain, and the story. They can also be crafted (expensive, shapeless): golden apple + diamond block + two themed items (feather/phantom membrane, obsidian/iron block, vine/moss block, ender eye/chorus fruit, heart of the sea/prismarine crystals, totem/iron block).

## Story Act II: Wall and Sea
After the Brood Mother falls, the story continues:
1. Tova spots black sails. **Captain Sela Marrow**, a Tidefruit eater, joins the camp. She's animated with dripping water and hands that stir the tide. She gives you her **sloop** and a **treasure map**.
2. Follow the map and unearth the cache, which holds a power fruit.
3. Sela teaches you to use your power: use it 5 times.
4. Bram arms your ship with cannons. Defeat 5 corsairs.
5. Reyne learns the truth: Vane has been luring giants inland with red flares. **Defeat the Storm Corsair.**
6. Become the **Warden of Wall and Sea**.
