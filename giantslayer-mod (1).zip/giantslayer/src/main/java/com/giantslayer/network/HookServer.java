package com.giantslayer.network;

import com.giantslayer.GiantSlayer;
import com.giantslayer.item.ManeuverGearItem;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingFallEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.handling.IPayloadContext;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Server side of the maneuver gear: gas drain, fall protection. */
@EventBusSubscriber(modid = GiantSlayer.MODID)
public class HookServer {
    private record State(boolean hooked, boolean boosting) {}
    private static final Map<UUID, State> STATES = new ConcurrentHashMap<>();

    public static void handleHookState(HookStatePayload payload, IPayloadContext ctx) {
        ctx.enqueueWork(() -> {
            Player p = ctx.player();
            State prev = STATES.get(p.getUUID());
            if (payload.hooked() && (prev == null || !prev.hooked()) && p instanceof ServerPlayer sp) {
                com.giantslayer.story.StoryManager.onGrapple(sp);
            }
            if (!payload.hooked() && !payload.boosting()) STATES.remove(p.getUUID());
            else STATES.put(p.getUUID(), new State(payload.hooked(), payload.boosting()));
        });
    }

    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        State s = STATES.get(player.getUUID());
        if (s == null) return;

        player.resetFallDistance();
        if (player.getAbilities().instabuild) return; // creative = infinite gas

        ItemStack gear = ManeuverGearItem.findGear(player);
        if (ManeuverGearItem.gas(gear) <= 0) {
            STATES.remove(player.getUUID());
            PacketDistributor.sendToPlayer(player, new OutOfGasPayload());
            return;
        }
        int cost = 0;
        if (s.hooked() && player.tickCount % 10 == 0) cost++;
        if (s.boosting() && player.tickCount % 2 == 0) cost++;
        if (cost > 0) ManeuverGearItem.useGas(gear, cost);
    }

    @SubscribeEvent
    public static void onFall(LivingFallEvent event) {
        if (event.getEntity() instanceof Player p && ManeuverGearItem.gas(ManeuverGearItem.findGear(p)) > 0) {
            event.setDamageMultiplier(event.getDamageMultiplier() * 0.2f); // gear absorbs most landings
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        STATES.remove(event.getEntity().getUUID());
    }
}
