package com.giantslayer.network;

import com.giantslayer.GiantSlayer;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Client -> server key actions. 0 = use fruit power (G), 1 = ship broadside (B). */
public record ActionPayload(int action) implements CustomPacketPayload {
    public static final int POWER = 0, BROADSIDE = 1;
    public static final Type<ActionPayload> TYPE = new Type<>(GiantSlayer.id("action"));
    public static final StreamCodec<ByteBuf, ActionPayload> STREAM_CODEC =
            ByteBufCodecs.VAR_INT.map(ActionPayload::new, ActionPayload::action);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
