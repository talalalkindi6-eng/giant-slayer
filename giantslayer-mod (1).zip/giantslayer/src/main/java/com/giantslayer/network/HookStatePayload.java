package com.giantslayer.network;

import com.giantslayer.GiantSlayer;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Client -> server: "I am hooked / boosting" so the server can drain gas and cancel fall damage. */
public record HookStatePayload(boolean hooked, boolean boosting) implements CustomPacketPayload {
    public static final Type<HookStatePayload> TYPE = new Type<>(GiantSlayer.id("hook_state"));

    public static final StreamCodec<ByteBuf, HookStatePayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.BOOL, HookStatePayload::hooked,
            ByteBufCodecs.BOOL, HookStatePayload::boosting,
            HookStatePayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
