package com.giantslayer.network;

import net.neoforged.fml.loading.FMLEnvironment;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

public class ModNetwork {
    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("1");
        registrar.playToServer(HookStatePayload.TYPE, HookStatePayload.STREAM_CODEC, HookServer::handleHookState);
        registrar.playToServer(ActionPayload.TYPE, ActionPayload.STREAM_CODEC, (payload, ctx) -> ctx.enqueueWork(() -> {
            if (!(ctx.player() instanceof net.minecraft.server.level.ServerPlayer sp)) return;
            if (payload.action() == ActionPayload.POWER) com.giantslayer.power.PowerManager.useAbility(sp);
            else if (payload.action() == ActionPayload.BROADSIDE) com.giantslayer.entity.ShipEntity.fireBroadside(sp);
        }));
        registrar.playToClient(OutOfGasPayload.TYPE, OutOfGasPayload.STREAM_CODEC,
                (payload, ctx) -> ctx.enqueueWork(() -> HookSync.forceRelease = true));
        registrar.playToClient(DialoguePayload.TYPE, DialoguePayload.STREAM_CODEC,
                (payload, ctx) -> ctx.enqueueWork(() -> {
                    // Only touch client classes on the client, so dedicated servers never load them.
                    if (FMLEnvironment.dist.isClient()) com.giantslayer.client.ClientPayloads.openDialogue(payload);
                }));
    }
}
