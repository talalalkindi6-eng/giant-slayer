package com.giantslayer.network;

import com.giantslayer.GiantSlayer;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Server -> client: your tank is empty, let go. */
public record OutOfGasPayload() implements CustomPacketPayload {
    public static final Type<OutOfGasPayload> TYPE = new Type<>(GiantSlayer.id("out_of_gas"));
    public static final StreamCodec<ByteBuf, OutOfGasPayload> STREAM_CODEC = StreamCodec.unit(new OutOfGasPayload());

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
