package com.giantslayer.network;

import com.giantslayer.GiantSlayer;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

import java.util.List;

/** Server -> client: open the dialogue screen with these lang keys, spoken by this NPC. */
public record DialoguePayload(int entityId, String character, List<String> lines) implements CustomPacketPayload {
    public static final Type<DialoguePayload> TYPE = new Type<>(GiantSlayer.id("dialogue"));

    public static final StreamCodec<ByteBuf, DialoguePayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, DialoguePayload::entityId,
            ByteBufCodecs.STRING_UTF8, DialoguePayload::character,
            ByteBufCodecs.STRING_UTF8.apply(ByteBufCodecs.list()), DialoguePayload::lines,
            DialoguePayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
