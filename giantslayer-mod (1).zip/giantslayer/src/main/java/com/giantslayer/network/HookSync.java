package com.giantslayer.network;

/** Tiny shared flag so the network handler never touches client-only classes. */
public final class HookSync {
    public static volatile boolean forceRelease = false;
    private HookSync() {}
}
