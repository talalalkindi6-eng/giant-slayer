package com.giantslayer;

import com.giantslayer.entity.*;
import net.minecraft.world.entity.EntityType;
import com.giantslayer.network.ModNetwork;
import com.giantslayer.registry.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;

@Mod(GiantSlayer.MODID)
public class GiantSlayer {
    public static final String MODID = "giantslayer";

    public GiantSlayer(IEventBus modBus, ModContainer container) {
        ModArmorMaterials.MATERIALS.register(modBus);
        ModBlocks.BLOCKS.register(modBus);
        ModItems.ITEMS.register(modBus);
        ModEntities.ENTITY_TYPES.register(modBus);
        ModFeatures.FEATURES.register(modBus);
        ModCreativeTab.TABS.register(modBus);
        ModAttachments.ATTACHMENTS.register(modBus);

        modBus.addListener(this::onAttributes);
        modBus.addListener(this::onSpawnPlacements);
        modBus.addListener(ModNetwork::register);
    }

    private void onAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.GIANT.get(), GiantEntity.createAttributes().build());
        event.put(ModEntities.SPRINTER.get(), SprinterGiant.createAttributes().build());
        event.put(ModEntities.LEAPER.get(), LeaperGiant.createAttributes().build());
        event.put(ModEntities.HOWLER.get(), HowlerGiant.createAttributes().build());
        event.put(ModEntities.BURROWER.get(), BurrowerGiant.createAttributes().build());
        event.put(ModEntities.BROOD.get(), BroodGiant.createAttributes().build());
        event.put(ModEntities.STORY_NPC.get(), StoryNpc.createAttributes().build());
        event.put(ModEntities.PIRATE.get(), PirateEntity.createAttributes().build());
        event.put(ModEntities.PIRATE_CAPTAIN.get(), PirateCaptainEntity.createAttributes().build());
    }

    private void onSpawnPlacements(RegisterSpawnPlacementsEvent event) {
        place(event, ModEntities.GIANT.get());
        place(event, ModEntities.SPRINTER.get());
        place(event, ModEntities.LEAPER.get());
        place(event, ModEntities.HOWLER.get());
        place(event, ModEntities.BURROWER.get());
        place(event, ModEntities.BROOD.get());
        event.register(ModEntities.PIRATE.get(), SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                net.minecraft.world.entity.monster.Monster::checkMonsterSpawnRules, RegisterSpawnPlacementsEvent.Operation.REPLACE);
    }

    private static <T extends GiantEntity> void place(RegisterSpawnPlacementsEvent event, EntityType<T> type) {
        event.register(type, SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                GiantEntity::checkGiantSpawnRules, RegisterSpawnPlacementsEvent.Operation.REPLACE);
    }

    public static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath(MODID, path);
    }
}
