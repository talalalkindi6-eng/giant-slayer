package com.giantslayer.story;

import com.giantslayer.registry.ModItems;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** The cast of the Ember Watch camp. */
public enum NpcCharacter {
    REYNE("reyne", 0.8f),   // Commander Halvard Reyne
    MIRA("mira", 1.3f),     // Mira Thale, scout instructor
    BRAM("bram", 0.6f),     // Old Bram, the smith
    TOVA("tova", 1.7f),     // Tova, runner & lookout
    SELA("sela", 1.1f);     // Captain Sela Marrow, Tidefruit eater

    public final String id;
    public final float voicePitch;

    NpcCharacter(String id, float voicePitch) {
        this.id = id;
        this.voicePitch = voicePitch;
    }

    public static NpcCharacter byIndex(int i) {
        NpcCharacter[] v = values();
        return v[Mth.clamp(i, 0, v.length - 1)];
    }

    public static NpcCharacter byName(String name) {
        for (NpcCharacter c : values()) if (c.id.equals(name)) return c;
        return REYNE;
    }

    public ItemStack heldItem() {
        return switch (this) {
            case MIRA -> new ItemStack(ModItems.SLAYER_BLADE.get());
            case BRAM -> new ItemStack(Items.IRON_AXE);
            case TOVA -> new ItemStack(Items.MAP);
            case SELA -> new ItemStack(Items.TRIDENT);
            default -> ItemStack.EMPTY;
        };
    }
}
