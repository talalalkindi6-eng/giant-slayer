package com.giantslayer.story;

import com.giantslayer.GiantSlayer;
import com.giantslayer.entity.*;
import com.giantslayer.network.DialoguePayload;
import com.giantslayer.registry.ModAttachments;
import com.giantslayer.registry.ModEntities;
import com.giantslayer.registry.ModItems;
import com.giantslayer.world.WallZones;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.network.PacketDistributor;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.BiConsumer;

/**
 * The "Ember Watch" campaign. Even stages are mostly "talk to X", odd ones are objectives.
 *
 *  0 talk Reyne -> 1 talk Mira (gets gear) -> 2 grapple x10 -> 3 talk Mira -> 4 talk Bram (blades)
 *  -> 5 nape kill -> 6 talk Reyne -> 7 slay 3 giants -> 8 talk Tova -> 9 slay the Howler
 *  -> 10 talk Reyne (wall charter) -> 11 raise a wall -> 12 talk Tova -> 13 slay the Brood Mother
 *  -> 14 talk Reyne -> 15 talk Tova (a ship arrives) -> 16 talk Sela (ship + treasure map)
 *  -> 17 find the buried cache -> 18 talk Sela (power fruit) -> 19 use your power x5
 *  -> 20 talk Bram (cannonballs) -> 21 defeat 5 pirates -> 22 talk Reyne
 *  -> 23 defeat Captain Morrow Vane -> 24 talk Reyne -> 25 complete
 */
@EventBusSubscriber(modid = GiantSlayer.MODID)
public class StoryManager {
    public static final int FINAL_STAGE = 25;

    private record Step(NpcCharacter who, String dialogue, int next, @Nullable BiConsumer<ServerPlayer, StoryNpc> action) {}

    private static final Map<Integer, Step> TALK_STEPS = new HashMap<>();
    private static final Map<Integer, Integer> GOALS = Map.ofEntries(
            Map.entry(2, 10), Map.entry(5, 1), Map.entry(7, 3), Map.entry(9, 1), Map.entry(11, 1), Map.entry(13, 1),
            Map.entry(17, 1), Map.entry(19, 5), Map.entry(21, 5), Map.entry(23, 1));
    /** How many lines each dialogue has in the lang file (story.giantslayer.<key>.<n>). */
    private static final Map<String, Integer> LINES = new HashMap<>();

    static {
        TALK_STEPS.put(0, new Step(NpcCharacter.REYNE, "reyne_intro", 1, null));
        TALK_STEPS.put(1, new Step(NpcCharacter.MIRA, "mira_gear", 2, (sp, npc) -> {
            give(sp, new ItemStack(ModItems.MANEUVER_GEAR.get()));
            give(sp, new ItemStack(ModItems.GAS_CANISTER.get(), 2));
        }));
        TALK_STEPS.put(3, new Step(NpcCharacter.MIRA, "mira_done", 4, null));
        TALK_STEPS.put(4, new Step(NpcCharacter.BRAM, "bram_blades", 5, (sp, npc) -> {
            give(sp, new ItemStack(ModItems.SLAYER_BLADE.get(), 2));
            spawnNear(sp, ModEntities.GIANT.get(), 30, 1.5);
        }));
        TALK_STEPS.put(6, new Step(NpcCharacter.REYNE, "reyne_proven", 7, (sp, npc) -> {
            spawnNear(sp, ModEntities.GIANT.get(), 40, null);
            spawnNear(sp, ModEntities.SPRINTER.get(), 45, null);
            spawnNear(sp, ModEntities.LEAPER.get(), 50, null);
        }));
        TALK_STEPS.put(8, new Step(NpcCharacter.TOVA, "tova_howler", 9, (sp, npc) -> spawnNear(sp, ModEntities.HOWLER.get(), 40, null)));
        TALK_STEPS.put(10, new Step(NpcCharacter.REYNE, "reyne_wall", 11, (sp, npc) -> give(sp, new ItemStack(ModItems.WALL_CHARTER.get()))));
        TALK_STEPS.put(12, new Step(NpcCharacter.TOVA, "tova_brood", 13, (sp, npc) -> spawnNear(sp, ModEntities.BROOD.get(), 50, null)));
        TALK_STEPS.put(14, new Step(NpcCharacter.REYNE, "reyne_final", 15, (sp, npc) -> {
            give(sp, new ItemStack(ModItems.GAS_CANISTER.get(), 8));
            give(sp, new ItemStack(ModItems.SLAYER_BLADE.get(), 2));
            give(sp, new ItemStack(Items.DIAMOND, 5));
            give(sp, new ItemStack(Items.TOTEM_OF_UNDYING));
        }));

        // ---- Act II: Wall and Sea ----
        TALK_STEPS.put(15, new Step(NpcCharacter.TOVA, "tova_ship", 16, (sp, npc) -> spawnSela(sp.serverLevel(), npc.blockPosition())));
        TALK_STEPS.put(16, new Step(NpcCharacter.SELA, "sela_intro", 17, (sp, npc) -> {
            give(sp, new ItemStack(ModItems.SHIP.get()));
            give(sp, new ItemStack(ModItems.TREASURE_MAP.get()));
        }));
        TALK_STEPS.put(18, new Step(NpcCharacter.SELA, "sela_treasure", 19, (sp, npc) -> {
            boolean hasFruit = com.giantslayer.power.PowerManager.fruitOf(sp) != null;
            boolean carrying = sp.getInventory().items.stream().anyMatch(st -> st.getItem() instanceof com.giantslayer.item.PowerFruitItem);
            if (!hasFruit && !carrying) give(sp, new ItemStack(ModItems.TIDE_FRUIT.get())); // fallback if the chest was emptied
        }));
        TALK_STEPS.put(20, new Step(NpcCharacter.BRAM, "bram_cannons", 21, (sp, npc) -> {
            give(sp, new ItemStack(ModItems.CANNONBALL.get(), 32));
            for (int i = 0; i < 5; i++) spawnNear(sp, ModEntities.PIRATE.get(), 25 + i * 3, null);
        }));
        TALK_STEPS.put(22, new Step(NpcCharacter.REYNE, "reyne_corsair", 23, (sp, npc) -> {
            spawnNear(sp, ModEntities.PIRATE_CAPTAIN.get(), 35, null);
            for (int i = 0; i < 3; i++) spawnNear(sp, ModEntities.PIRATE.get(), 32, null);
        }));
        TALK_STEPS.put(24, new Step(NpcCharacter.REYNE, "reyne_victory", 25, (sp, npc) -> {
            give(sp, new ItemStack(Items.NETHERITE_INGOT, 2));
            give(sp, new ItemStack(Items.ENCHANTED_GOLDEN_APPLE, 2));
            give(sp, new ItemStack(ModItems.THUNDER_LANCE.get(), 8));
            give(sp, new ItemStack(ModItems.TREASURE_MAP.get()));
        }));

        LINES.put("tova_ship", 4);
        LINES.put("sela_intro", 6);
        LINES.put("sela_treasure", 5);
        LINES.put("bram_cannons", 5);
        LINES.put("reyne_corsair", 5);
        LINES.put("reyne_victory", 5);
        LINES.put("reyne_intro", 5);
        LINES.put("mira_gear", 5);
        LINES.put("mira_done", 3);
        LINES.put("bram_blades", 5);
        LINES.put("reyne_proven", 4);
        LINES.put("tova_howler", 5);
        LINES.put("reyne_wall", 5);
        LINES.put("tova_brood", 5);
        LINES.put("reyne_final", 5);
        for (NpcCharacter c : NpcCharacter.values()) LINES.put(c.id + "_idle", 3);
    }

    // ---------------------------------------------------------------- data

    public static StoryData get(ServerPlayer sp) { return sp.getData(ModAttachments.STORY); }
    private static void set(ServerPlayer sp, StoryData d) { sp.setData(ModAttachments.STORY, d); }

    // ---------------------------------------------------------------- talking

    public static void talk(ServerPlayer sp, StoryNpc npc) {
        StoryData d = get(sp);
        NpcCharacter who = npc.getCharacter();
        Step step = TALK_STEPS.get(d.stage());

        if (step != null && step.who() == who) {
            say(sp, npc, step.dialogue());
            if (step.action() != null) step.action().accept(sp, npc);
            advance(sp, step.next());
        } else {
            sayLine(sp, npc, who.id + "_idle", sp.getRandom().nextInt(3) + 1);
            showObjective(sp);
        }
    }

    private static void say(ServerPlayer sp, StoryNpc npc, String key) {
        int n = LINES.getOrDefault(key, 1);
        List<String> keys = new ArrayList<>();
        for (int i = 1; i <= n; i++) keys.add("story.giantslayer." + key + "." + i);
        PacketDistributor.sendToPlayer(sp, new DialoguePayload(npc.getId(), npc.getCharacter().id, keys));
    }

    private static void sayLine(ServerPlayer sp, StoryNpc npc, String key, int line) {
        PacketDistributor.sendToPlayer(sp, new DialoguePayload(npc.getId(), npc.getCharacter().id,
                List.of("story.giantslayer." + key + "." + line)));
    }

    // ---------------------------------------------------------------- progression

    private static void advance(ServerPlayer sp, int next) {
        set(sp, get(sp).withStage(next));
        sp.playNotifySound(SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 0.6f, 1.2f);
        sp.sendSystemMessage(Component.translatable("message.giantslayer.new_objective")
                .withStyle(ChatFormatting.GOLD)
                .append(Component.translatable("objective.giantslayer." + next).withStyle(ChatFormatting.YELLOW)));
    }

    private static void addProgress(ServerPlayer sp, int stage) {
        StoryData d = get(sp);
        if (d.stage() != stage) return;
        int goal = GOALS.getOrDefault(stage, 1);
        int p = d.progress() + 1;
        if (p >= goal) {
            sp.sendSystemMessage(Component.translatable("message.giantslayer.objective_done").withStyle(ChatFormatting.GREEN));
            advance(sp, stage + 1);
        } else {
            set(sp, d.withProgress(p));
            sp.displayClientMessage(Component.translatable("objective.giantslayer." + stage)
                    .append(" " + p + "/" + goal), true);
        }
    }

    public static void showObjective(ServerPlayer sp) {
        StoryData d = get(sp);
        Component msg = Component.translatable("message.giantslayer.current_objective").withStyle(ChatFormatting.GOLD)
                .append(Component.translatable("objective.giantslayer." + d.stage()).withStyle(ChatFormatting.YELLOW));
        if (GOALS.containsKey(d.stage())) msg = msg.copy().append(" (" + d.progress() + "/" + GOALS.get(d.stage()) + ")");
        sp.sendSystemMessage(msg);
    }

    private static void spawnSela(ServerLevel level, BlockPos near) {
        boolean present = !level.getEntitiesOfClass(StoryNpc.class, new net.minecraft.world.phys.AABB(near).inflate(96),
                n -> n.getCharacter() == NpcCharacter.SELA).isEmpty();
        if (present) return;
        StoryNpc sela = ModEntities.STORY_NPC.get().create(level);
        if (sela == null) return;
        BlockPos at = near.offset(2, 0, 2);
        int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, at.getX(), at.getZ());
        sela.moveTo(at.getX() + 0.5, y, at.getZ() + 0.5, 0f, 0f);
        sela.setCharacter(NpcCharacter.SELA);
        sela.setHome(near);
        level.addFreshEntity(sela);
    }

    // Hooks called from gameplay code
    public static void onTreasureFound(ServerPlayer sp) { addProgress(sp, 17); }
    public static void onPowerUsed(ServerPlayer sp) { addProgress(sp, 19); }
    public static void onGrapple(ServerPlayer sp) { addProgress(sp, 2); }
    public static void onWallBuilt(ServerPlayer sp) { addProgress(sp, 11); }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        if (!(event.getSource().getEntity() instanceof ServerPlayer sp)) return;
        if (event.getEntity() instanceof PirateEntity) addProgress(sp, 21);
        if (event.getEntity() instanceof PirateCaptainEntity) {
            addProgress(sp, 23);
            // Vane's crew flees when he falls.
            for (PirateEntity p : sp.serverLevel().getEntitiesOfClass(PirateEntity.class, event.getEntity().getBoundingBox().inflate(48))) {
                p.addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.WEAKNESS, 600, 2));
            }
        }
        if (!(event.getEntity() instanceof GiantEntity giant)) return;
        if (giant.napeCut) addProgress(sp, 5);
        addProgress(sp, 7);
        if (giant instanceof HowlerGiant) addProgress(sp, 9);
        if (giant instanceof BroodGiant) addProgress(sp, 13);
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer sp)) return;
        StoryData d = get(sp);
        if (!d.journalGiven()) {
            give(sp, new ItemStack(ModItems.STORY_JOURNAL.get()));
            set(sp, d.withJournal());
            sp.sendSystemMessage(Component.translatable("message.giantslayer.journal_given").withStyle(ChatFormatting.GOLD));
        }
    }

    // ---------------------------------------------------------------- helpers

    private static void give(ServerPlayer sp, ItemStack stack) {
        if (!sp.getInventory().add(stack)) sp.drop(stack, false);
    }

    /** Spawns a giant some distance away (never inside a wall ring) and sets it on the player. */
    private static void spawnNear(ServerPlayer sp, EntityType<? extends net.minecraft.world.entity.Mob> type, double dist, @Nullable Double scale) {
        ServerLevel sl = sp.serverLevel();
        for (int attempt = 0; attempt < 12; attempt++) {
            double a = sp.getRandom().nextDouble() * Math.PI * 2;
            int x = (int) (sp.getX() + Math.cos(a) * dist);
            int z = (int) (sp.getZ() + Math.sin(a) * dist);
            BlockPos pos = new BlockPos(x, sl.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z), z);
            if (attempt < 11 && WallZones.get(sl).isProtected(pos)) continue;

            net.minecraft.world.entity.Mob g = type.create(sl);
            if (g == null) return;
            g.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, sp.getRandom().nextFloat() * 360f, 0f);
            g.finalizeSpawn(sl, sl.getCurrentDifficultyAt(pos), MobSpawnType.EVENT, null);
            if (scale != null && g instanceof GiantEntity giant) giant.setGiantScale(scale);
            g.setPersistenceRequired();
            g.setTarget(sp);
            sl.addFreshEntity(g);
            return;
        }
    }
}
