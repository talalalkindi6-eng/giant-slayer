package com.giantslayer.story;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

/** Per-player story progress. Saved with the player and kept through death. */
public record StoryData(int stage, int progress, boolean journalGiven, boolean campBuilt) {
    public static final StoryData EMPTY = new StoryData(0, 0, false, false);

    public static final Codec<StoryData> CODEC = RecordCodecBuilder.create(i -> i.group(
            Codec.INT.fieldOf("stage").forGetter(StoryData::stage),
            Codec.INT.fieldOf("progress").forGetter(StoryData::progress),
            Codec.BOOL.fieldOf("journal").forGetter(StoryData::journalGiven),
            Codec.BOOL.fieldOf("camp").forGetter(StoryData::campBuilt)
    ).apply(i, StoryData::new));

    public StoryData withStage(int s) { return new StoryData(s, 0, journalGiven, campBuilt); }
    public StoryData withProgress(int p) { return new StoryData(stage, p, journalGiven, campBuilt); }
    public StoryData withJournal() { return new StoryData(stage, progress, true, campBuilt); }
    public StoryData withCamp() { return new StoryData(stage, progress, journalGiven, true); }
}
