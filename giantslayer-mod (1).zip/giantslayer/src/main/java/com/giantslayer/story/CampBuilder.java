package com.giantslayer.story;

import com.giantslayer.entity.StoryNpc;
import com.giantslayer.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;

/** Builds the small Ember Watch camp and spawns its four characters. */
public class CampBuilder {
    private static final int RADIUS = 7;

    public static void build(ServerLevel level, BlockPos around) {
        BlockPos center = ground(level, around.getX(), around.getZ());

        place(level, center, Blocks.CAMPFIRE.defaultBlockState());
        place(level, ground(level, center.getX() + 3, center.getZ() + 2), Blocks.BARREL.defaultBlockState());
        place(level, ground(level, center.getX() + 3, center.getZ() + 3), Blocks.BARREL.defaultBlockState());
        place(level, ground(level, center.getX() - 3, center.getZ() + 2), Blocks.CRAFTING_TABLE.defaultBlockState());
        place(level, ground(level, center.getX() + 3, center.getZ() - 2), Blocks.ANVIL.defaultBlockState());
        place(level, ground(level, center.getX() + 4, center.getZ() - 2), Blocks.SMITHING_TABLE.defaultBlockState());
        place(level, ground(level, center.getX() - 3, center.getZ() - 3), Blocks.HAY_BLOCK.defaultBlockState());
        place(level, ground(level, center.getX() - 4, center.getZ() - 3), Blocks.HAY_BLOCK.defaultBlockState());

        // Fence ring with a gap on the south side, lanterns every so often.
        int n = 0;
        for (int dx = -RADIUS; dx <= RADIUS; dx++) {
            for (int dz = -RADIUS; dz <= RADIUS; dz++) {
                if (Math.round(Math.sqrt(dx * dx + dz * dz)) != RADIUS) continue;
                if (dz > 0 && Math.abs(dx) <= 1) continue;
                BlockPos p = ground(level, center.getX() + dx, center.getZ() + dz);
                place(level, p, Blocks.OAK_FENCE.defaultBlockState());
                if (n++ % 7 == 0) place(level, p.above(), Blocks.LANTERN.defaultBlockState());
            }
        }

        spawn(level, center, NpcCharacter.REYNE, 0, -2);
        spawn(level, center, NpcCharacter.MIRA, -2, 0);
        spawn(level, center, NpcCharacter.BRAM, 2, -1);
        spawn(level, center, NpcCharacter.TOVA, 0, 3);
    }

    private static BlockPos ground(ServerLevel level, int x, int z) {
        return new BlockPos(x, level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z), z);
    }

    private static void place(ServerLevel level, BlockPos pos, BlockState state) {
        level.setBlock(pos, Block.updateFromNeighbourShapes(state, level, pos), 3);
    }

    private static void spawn(ServerLevel level, BlockPos center, NpcCharacter c, int dx, int dz) {
        StoryNpc npc = ModEntities.STORY_NPC.get().create(level);
        if (npc == null) return;
        BlockPos p = ground(level, center.getX() + dx, center.getZ() + dz);
        npc.moveTo(p.getX() + 0.5, p.getY(), p.getZ() + 0.5, level.random.nextFloat() * 360f, 0f);
        npc.setCharacter(c);
        npc.setHome(center);
        level.addFreshEntity(npc);
    }
}
