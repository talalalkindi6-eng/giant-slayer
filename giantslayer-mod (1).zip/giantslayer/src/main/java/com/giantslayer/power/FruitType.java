package com.giantslayer.power;

import com.giantslayer.registry.ModItems;
import net.minecraft.world.item.Item;
import org.jetbrains.annotations.Nullable;

/** The six power fruits. One per person, forever. Ability key: G. */
public enum FruitType {
    GALE("gale", 0.80f, 0.95f, 1.00f, 80),          // Gale Burst: rocket yourself forward, blast foes away
    STONEHIDE("stonehide", 0.55f, 0.50f, 0.45f, 400),// Stone Skin: heavy armor + ground slam
    THORNVINE("thornvine", 0.20f, 0.70f, 0.20f, 300),// Root Snare: vines pin everything in front of you
    BLINK("blink", 0.60f, 0.20f, 0.90f, 60),         // Blink: teleport where you look
    TIDE("tide", 0.20f, 0.55f, 1.00f, 200),          // Tidal Wave: crashing wave pushes everything back
    COLOSSUS("colossus", 0.90f, 0.45f, 0.30f, 900);  // Colossus Form: grow 3x for 15 seconds

    public final String id;
    public final float r, g, b;
    public final int cooldown;

    FruitType(String id, float r, float g, float b, int cooldown) {
        this.id = id; this.r = r; this.g = g; this.b = b; this.cooldown = cooldown;
    }

    @Nullable
    public static FruitType byId(String id) {
        for (FruitType t : values()) if (t.id.equals(id)) return t;
        return null;
    }

    public Item item() {
        return switch (this) {
            case GALE -> ModItems.GALE_FRUIT.get();
            case STONEHIDE -> ModItems.STONEHIDE_FRUIT.get();
            case THORNVINE -> ModItems.THORNVINE_FRUIT.get();
            case BLINK -> ModItems.BLINK_FRUIT.get();
            case TIDE -> ModItems.TIDE_FRUIT.get();
            case COLOSSUS -> ModItems.COLOSSUS_FRUIT.get();
        };
    }
}
