package com.giantslayer.power;

import com.giantslayer.GiantSlayer;
import com.giantslayer.entity.StoryNpc;
import com.giantslayer.network.OutOfGasPayload;
import com.giantslayer.registry.ModAttachments;
import com.giantslayer.story.StoryManager;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingFallEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;

import java.util.*;

/** Server-side logic for power fruits: eating, abilities, passives, and the casting aura animation. */
@EventBusSubscriber(modid = GiantSlayer.MODID)
public class PowerManager {
    private static final Map<UUID, Long> READY_AT = new HashMap<>();
    private static final Map<UUID, Integer> COLOSSUS = new HashMap<>();
    private static final int COLOSSUS_TIME = 300;
    private static final ResourceLocation SCALE_ID = GiantSlayer.id("colossus_scale");
    private static final ResourceLocation REACH_ID = GiantSlayer.id("colossus_reach");
    private static final ResourceLocation DAMAGE_ID = GiantSlayer.id("colossus_damage");

    @Nullable
    public static FruitType fruitOf(Player p) {
        return FruitType.byId(p.getData(ModAttachments.POWER));
    }

    // ------------------------------------------------------------ eating

    public static void eat(ServerPlayer sp, FruitType type) {
        if (fruitOf(sp) != null) {
            sp.addEffect(new MobEffectInstance(MobEffects.POISON, 200, 1));
            sp.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 200, 0));
            sp.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 600, 1));
            sp.sendSystemMessage(Component.translatable("message.giantslayer.fruit_rejected").withStyle(ChatFormatting.RED));
            return;
        }
        sp.setData(ModAttachments.POWER, type.id);
        sp.serverLevel().playSound(null, sp.blockPosition(), SoundEvents.TOTEM_USE, SoundSource.PLAYERS, 1.0f, 1.2f);
        aura(sp, type, 80);
        sp.sendSystemMessage(Component.translatable("message.giantslayer.fruit_eaten",
                Component.translatable("power.giantslayer." + type.id)).withStyle(ChatFormatting.GOLD));
        sp.sendSystemMessage(Component.translatable("power.giantslayer." + type.id + ".desc").withStyle(ChatFormatting.GRAY));
    }

    // ------------------------------------------------------------ abilities (key G)

    public static void useAbility(ServerPlayer sp) {
        FruitType t = fruitOf(sp);
        if (t == null) {
            sp.displayClientMessage(Component.translatable("message.giantslayer.no_power"), true);
            return;
        }
        long now = sp.serverLevel().getGameTime();
        long ready = READY_AT.getOrDefault(sp.getUUID(), 0L);
        if (now < ready && !sp.getAbilities().instabuild) {
            sp.displayClientMessage(Component.translatable("message.giantslayer.power_cooldown", (ready - now) / 20 + 1), true);
            return;
        }
        boolean used = switch (t) {
            case GALE -> galeBurst(sp);
            case STONEHIDE -> stoneSkin(sp);
            case THORNVINE -> rootSnare(sp);
            case BLINK -> blink(sp);
            case TIDE -> tidalWave(sp);
            case COLOSSUS -> colossus(sp);
        };
        if (!used) return;
        READY_AT.put(sp.getUUID(), now + t.cooldown);
        sp.swing(InteractionHand.MAIN_HAND, true);
        aura(sp, t, 40);
        sp.displayClientMessage(Component.translatable("power.giantslayer." + t.id + ".ability").withStyle(ChatFormatting.AQUA), true);
        StoryManager.onPowerUsed(sp);
    }

    private static boolean galeBurst(ServerPlayer sp) {
        Vec3 look = sp.getLookAngle();
        sp.setDeltaMovement(look.scale(2.2).add(0, 0.4, 0));
        sp.hurtMarked = true;
        sp.resetFallDistance();
        for (LivingEntity e : nearby(sp, 6.0)) push(e, sp.position(), 1.6, 0.5);
        ServerLevel sl = sp.serverLevel();
        sl.sendParticles(ParticleTypes.CLOUD, sp.getX(), sp.getY() + 1, sp.getZ(), 40, 1.5, 0.5, 1.5, 0.15);
        sl.playSound(null, sp.blockPosition(), SoundEvents.ENDER_DRAGON_FLAP, SoundSource.PLAYERS, 1.5f, 1.4f);
        return true;
    }

    private static boolean stoneSkin(ServerPlayer sp) {
        sp.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 160, 2));
        sp.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 160, 0));
        for (LivingEntity e : nearby(sp, 5.0)) {
            e.hurt(sp.damageSources().playerAttack(sp), 8.0f);
            push(e, sp.position(), 0.8, 0.7);
        }
        ServerLevel sl = sp.serverLevel();
        sl.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.STONE.defaultBlockState()),
                sp.getX(), sp.getY() + 0.2, sp.getZ(), 80, 2.5, 0.2, 2.5, 0.2);
        sl.playSound(null, sp.blockPosition(), SoundEvents.ANVIL_LAND, SoundSource.PLAYERS, 1.2f, 0.5f);
        return true;
    }

    private static boolean rootSnare(ServerPlayer sp) {
        ServerLevel sl = sp.serverLevel();
        BlockParticleOption leaves = new BlockParticleOption(ParticleTypes.BLOCK, Blocks.OAK_LEAVES.defaultBlockState());
        List<LivingEntity> hits = cone(sp, 16.0, 0.6);
        for (LivingEntity e : hits) {
            e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 10));
            e.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 1));
            sl.sendParticles(leaves, e.getX(), e.getY() + 0.3, e.getZ(), 40, e.getBbWidth(), e.getBbHeight() * 0.3, e.getBbWidth(), 0.1);
        }
        Vec3 look = sp.getLookAngle();
        for (int i = 1; i <= 16; i += 2) {
            sl.sendParticles(leaves, sp.getX() + look.x * i, sp.getY() + 0.2, sp.getZ() + look.z * i, 6, 0.3, 0.1, 0.3, 0.05);
        }
        sl.playSound(null, sp.blockPosition(), SoundEvents.GRASS_BREAK, SoundSource.PLAYERS, 2.0f, 0.5f);
        return true;
    }

    private static boolean blink(ServerPlayer sp) {
        HitResult hit = sp.pick(24.0, 1.0f, false);
        Vec3 target = hit.getLocation().subtract(sp.getLookAngle().scale(0.8));
        ServerLevel sl = sp.serverLevel();
        sl.sendParticles(ParticleTypes.REVERSE_PORTAL, sp.getX(), sp.getY() + 1, sp.getZ(), 40, 0.4, 0.8, 0.4, 0.05);
        sp.teleportTo(target.x, target.y, target.z);
        sp.resetFallDistance();
        sl.sendParticles(ParticleTypes.REVERSE_PORTAL, target.x, target.y + 1, target.z, 40, 0.4, 0.8, 0.4, 0.05);
        sl.playSound(null, sp.blockPosition(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1.0f, 1.3f);
        return true;
    }

    private static boolean tidalWave(ServerPlayer sp) {
        ServerLevel sl = sp.serverLevel();
        for (LivingEntity e : cone(sp, 12.0, 0.3)) {
            e.hurt(sp.damageSources().playerAttack(sp), 4.0f);
            e.clearFire();
            push(e, sp.position(), 2.0, 0.5);
        }
        sp.clearFire();
        Vec3 look = sp.getLookAngle();
        for (int i = 1; i <= 12; i++) {
            sl.sendParticles(ParticleTypes.SPLASH, sp.getX() + look.x * i, sp.getY() + 1, sp.getZ() + look.z * i, 25, 1.2, 0.8, 1.2, 0.2);
            sl.sendParticles(ParticleTypes.BUBBLE_POP, sp.getX() + look.x * i, sp.getY() + 0.5, sp.getZ() + look.z * i, 8, 1.0, 0.5, 1.0, 0.05);
        }
        sl.playSound(null, sp.blockPosition(), SoundEvents.GENERIC_SPLASH, SoundSource.PLAYERS, 2.0f, 0.6f);
        return true;
    }

    private static boolean colossus(ServerPlayer sp) {
        COLOSSUS.put(sp.getUUID(), COLOSSUS_TIME);
        sp.serverLevel().playSound(null, sp.blockPosition(), SoundEvents.RAVAGER_ROAR, SoundSource.PLAYERS, 2.0f, 0.7f);
        return true;
    }

    // ------------------------------------------------------------ helpers

    private static List<LivingEntity> nearby(ServerPlayer sp, double r) {
        return sp.serverLevel().getEntitiesOfClass(LivingEntity.class, sp.getBoundingBox().inflate(r),
                e -> e != sp && e.isAlive() && !(e instanceof StoryNpc) && e.distanceTo(sp) <= r);
    }

    private static List<LivingEntity> cone(ServerPlayer sp, double range, double minDot) {
        Vec3 look = sp.getLookAngle();
        Vec3 eye = sp.getEyePosition();
        List<LivingEntity> out = new ArrayList<>();
        for (LivingEntity e : nearby(sp, range)) {
            Vec3 to = e.position().add(0, e.getBbHeight() * 0.5, 0).subtract(eye).normalize();
            if (to.dot(look) >= minDot) out.add(e);
        }
        return out;
    }

    private static void push(LivingEntity e, Vec3 from, double strength, double lift) {
        Vec3 dir = new Vec3(e.getX() - from.x, 0, e.getZ() - from.z).normalize();
        e.setDeltaMovement(dir.scale(strength).add(0, lift, 0));
        e.hurtMarked = true;
        if (e instanceof ServerPlayer target) PacketDistributor.sendToPlayer(target, new OutOfGasPayload());
    }

    /** The fruit-eater "casting" animation: a colored spiral rising around the body. */
    public static void aura(ServerPlayer sp, FruitType t, int count) {
        ServerLevel sl = sp.serverLevel();
        DustParticleOptions dust = new DustParticleOptions(new Vector3f(t.r, t.g, t.b), 1.6f);
        double h = sp.getBbHeight();
        double rad = Math.max(0.8, sp.getBbWidth() * 1.4);
        for (int i = 0; i < count; i++) {
            double a = i * 0.55;
            double y = sp.getY() + (i / (double) count) * h * 1.1;
            sl.sendParticles(dust, sp.getX() + Math.cos(a) * rad, y, sp.getZ() + Math.sin(a) * rad, 1, 0, 0, 0, 0);
        }
    }

    private static void setColossus(ServerPlayer sp, double bonus) {
        apply(sp.getAttribute(Attributes.SCALE), SCALE_ID, bonus, AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
        apply(sp.getAttribute(Attributes.ENTITY_INTERACTION_RANGE), REACH_ID, bonus * 2.0, AttributeModifier.Operation.ADD_VALUE);
        apply(sp.getAttribute(Attributes.ATTACK_DAMAGE), DAMAGE_ID, bonus * 4.0, AttributeModifier.Operation.ADD_VALUE);
    }

    private static void apply(@Nullable AttributeInstance inst, ResourceLocation id, double value, AttributeModifier.Operation op) {
        if (inst == null) return;
        inst.removeModifier(id);
        if (value > 0.001) inst.addTransientModifier(new AttributeModifier(id, value, op));
    }

    // ------------------------------------------------------------ ticking: passives + colossus growth

    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        if (!(event.getEntity() instanceof ServerPlayer sp)) return;

        Integer c = COLOSSUS.get(sp.getUUID());
        if (c != null) {
            c--;
            int grown = COLOSSUS_TIME - c;
            double bonus = grown < 20 ? grown / 20.0 * 2.0 : c < 20 ? c / 20.0 * 2.0 : 2.0; // grow, hold, shrink
            setColossus(sp, bonus);
            if (c % 10 == 0) aura(sp, FruitType.COLOSSUS, 12);
            if (c <= 0) { COLOSSUS.remove(sp.getUUID()); setColossus(sp, 0); }
            else COLOSSUS.put(sp.getUUID(), c);
        }

        if (sp.tickCount % 20 != 0) return;
        FruitType t = fruitOf(sp);
        if (t == null) return;
        switch (t) {
            case STONEHIDE -> sp.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 40, 0, true, false));
            case TIDE -> {
                if (sp.isInWater()) {
                    sp.addEffect(new MobEffectInstance(MobEffects.WATER_BREATHING, 60, 0, true, false));
                    sp.addEffect(new MobEffectInstance(MobEffects.DOLPHINS_GRACE, 60, 0, true, false));
                }
            }
            case THORNVINE -> {
                if (sp.level().getBlockState(sp.blockPosition().below()).is(Blocks.GRASS_BLOCK)) {
                    sp.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 60, 0, true, false));
                }
            }
            case BLINK -> sp.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 260, 0, true, false));
            case COLOSSUS -> sp.addEffect(new MobEffectInstance(MobEffects.HEALTH_BOOST, 40, 0, true, false));
            case GALE -> { }
        }
        if (sp.tickCount % 60 == 0) aura(sp, t, 6); // faint idle aura so fruit-eaters are recognizable
    }

    @SubscribeEvent
    public static void onFall(LivingFallEvent event) {
        if (event.getEntity() instanceof Player p && fruitOf(p) == FruitType.GALE) {
            event.setDamageMultiplier(event.getDamageMultiplier() * 0.5f);
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp && COLOSSUS.remove(sp.getUUID()) != null) setColossus(sp, 0);
    }
}
