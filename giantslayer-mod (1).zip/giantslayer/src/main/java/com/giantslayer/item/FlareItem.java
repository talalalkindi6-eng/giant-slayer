package com.giantslayer.item;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

import java.util.List;

/** Flare cartridge: ammo for the Flare Pistol. */
public class FlareItem extends Item {
    public final FlareColor color;

    public FlareItem(FlareColor color, Properties props) {
        super(props);
        this.color = color;
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext ctx, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.giantslayer.flare_" + color.name().toLowerCase()).withStyle(ChatFormatting.GRAY));
    }
}
