package com.giantslayer.item;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

import java.util.List;

/**
 * Maneuver gear: keep it anywhere in your inventory. The durability bar is your gas tank.
 * Hold the Hook key (R) to fire a grapple line, Boost key (V) for a gas burst.
 */
public class ManeuverGearItem extends Item {
    public static final int MAX_GAS = 600;

    public ManeuverGearItem(Properties props) {
        super(props);
    }

    public static ItemStack findGear(Player player) {
        for (ItemStack s : player.getInventory().items) {
            if (s.getItem() instanceof ManeuverGearItem) return s;
        }
        for (ItemStack s : player.getInventory().offhand) {
            if (s.getItem() instanceof ManeuverGearItem) return s;
        }
        return ItemStack.EMPTY;
    }

    public static int gas(ItemStack stack) {
        return stack.isEmpty() ? 0 : stack.getMaxDamage() - stack.getDamageValue();
    }

    public static void useGas(ItemStack stack, int amount) {
        stack.setDamageValue(Math.min(stack.getMaxDamage(), stack.getDamageValue() + amount));
    }

    public static void refill(ItemStack stack) {
        stack.setDamageValue(0);
    }

    @Override public boolean isBarVisible(ItemStack stack) { return true; }
    @Override public int getBarColor(ItemStack stack) { return 0x5BC8F5; }
    @Override public boolean isEnchantable(ItemStack stack) { return false; }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext ctx, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.giantslayer.gas", gas(stack), MAX_GAS).withStyle(ChatFormatting.AQUA));
        tooltip.add(Component.translatable("tooltip.giantslayer.gear_help").withStyle(ChatFormatting.GRAY));
    }
}
