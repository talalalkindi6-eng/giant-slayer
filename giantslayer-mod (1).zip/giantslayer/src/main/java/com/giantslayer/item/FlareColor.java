package com.giantslayer.item;

import com.giantslayer.registry.ModItems;
import net.minecraft.util.Mth;
import net.minecraft.world.item.Item;

/**
 * GREEN  - reveals every giant within 128 blocks (they glow for 20s).
 * RED    - lures giants within 96 blocks toward where the flare burst.
 * BLACK  - smoke screen: giants within 40 blocks lose track of everyone for 8s.
 */
public enum FlareColor {
    GREEN(0.25f, 1.0f, 0.35f),
    RED(1.0f, 0.2f, 0.2f),
    BLACK(0.1f, 0.1f, 0.1f);

    public final float r, g, b;

    FlareColor(float r, float g, float b) { this.r = r; this.g = g; this.b = b; }

    public static FlareColor byIndex(int i) { return values()[Mth.clamp(i, 0, values().length - 1)]; }

    public Item item() {
        return switch (this) {
            case GREEN -> ModItems.GREEN_FLARE.get();
            case RED -> ModItems.RED_FLARE.get();
            case BLACK -> ModItems.BLACK_FLARE.get();
        };
    }
}
