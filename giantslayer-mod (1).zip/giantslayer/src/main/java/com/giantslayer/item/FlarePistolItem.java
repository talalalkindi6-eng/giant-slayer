package com.giantslayer.item;

import com.giantslayer.entity.projectile.FlareEntity;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import java.util.List;

/** Fires the flare in your offhand, or else the first flare found in your inventory. */
public class FlarePistolItem extends Item {
    public FlarePistolItem(Properties props) { super(props); }

    private static ItemStack findFlare(Player p) {
        if (p.getOffhandItem().getItem() instanceof FlareItem) return p.getOffhandItem();
        for (ItemStack s : p.getInventory().items) if (s.getItem() instanceof FlareItem) return s;
        return ItemStack.EMPTY;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack pistol = player.getItemInHand(hand);
        ItemStack ammo = findFlare(player);
        if (ammo.isEmpty()) {
            if (!level.isClientSide) player.displayClientMessage(Component.translatable("message.giantslayer.no_flares"), true);
            return InteractionResultHolder.fail(pistol);
        }
        if (!level.isClientSide) {
            FlareColor color = ((FlareItem) ammo.getItem()).color;
            FlareEntity flare = new FlareEntity(level, player, color);
            flare.shootFromRotation(player, player.getXRot(), player.getYRot(), 0.0f, 1.6f, 0.5f);
            level.addFreshEntity(flare);
            level.playSound(null, player.blockPosition(), SoundEvents.FIREWORK_ROCKET_LAUNCH, SoundSource.PLAYERS, 1.5f, 0.8f);
            if (!player.getAbilities().instabuild) ammo.shrink(1);
            pistol.hurtAndBreak(1, player, slotFor(hand));
        }
        player.getCooldowns().addCooldown(this, 30);
        return InteractionResultHolder.sidedSuccess(pistol, level.isClientSide);
    }

    private static net.minecraft.world.entity.EquipmentSlot slotFor(InteractionHand hand) {
        return hand == InteractionHand.MAIN_HAND ? net.minecraft.world.entity.EquipmentSlot.MAINHAND : net.minecraft.world.entity.EquipmentSlot.OFFHAND;
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext ctx, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.giantslayer.flare_pistol").withStyle(ChatFormatting.GRAY));
    }
}
