package com.giantslayer.item;

import com.giantslayer.world.WallBuilder;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

import java.util.List;

/**
 * Use on the ground to raise a circular wall around that spot.
 * Normal use: radius 40, 24 high. Sneak-use: radius 96, 40 high.
 * The gate opens in the direction you are facing.
 */
public class WallCharterItem extends Item {
    public WallCharterItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        if (level.isClientSide) return InteractionResult.SUCCESS;

        Player player = ctx.getPlayer();
        boolean big = player != null && player.isShiftKeyDown();
        int radius = big ? 96 : 40;
        int height = big ? 40 : 24;
        BlockPos center = ctx.getClickedPos().above();

        WallBuilder.start((ServerLevel) level, center, radius, height, ctx.getHorizontalDirection(), player);
        if (player != null && !player.getAbilities().instabuild) ctx.getItemInHand().shrink(1);
        return InteractionResult.CONSUME;
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext ctx, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.giantslayer.charter_help").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.giantslayer.charter_help2").withStyle(ChatFormatting.DARK_GRAY));
    }
}
