package com.giantslayer.item;

import com.giantslayer.GiantSlayer;
import com.giantslayer.entity.GiantEntity;
import com.giantslayer.registry.ModItems;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingChangeTargetEvent;

/** Scout Cloak camouflage: while sneaking, giants more than 10 blocks away can't lock onto you. */
@EventBusSubscriber(modid = GiantSlayer.MODID)
public class ItemEvents {
    @SubscribeEvent
    public static void onTarget(LivingChangeTargetEvent event) {
        if (!(event.getEntity() instanceof GiantEntity giant)) return;
        if (!(event.getNewAboutToBeSetTarget() instanceof Player p)) return;
        if (p.getItemBySlot(EquipmentSlot.CHEST).is(ModItems.SCOUT_CLOAK.get())
                && p.isShiftKeyDown() && giant.distanceTo(p) > 10.0f) {
            event.setCanceled(true);
        }
    }
}
