package com.giantslayer.item;

import com.giantslayer.GiantSlayer;
import com.giantslayer.power.FruitType;
import com.giantslayer.story.StoryManager;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.entity.RandomizableContainer;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.storage.loot.LootTable;

import java.util.List;

/**
 * Right-click: the first time, it reveals a spot 150-400 blocks away. Each use tells you
 * the distance and direction. Within 6 blocks of the spot, the cache is unearthed under a red X.
 */
public class TreasureMapItem extends Item {
    private static final ResourceKey<LootTable> LOOT =
            ResourceKey.create(Registries.LOOT_TABLE, GiantSlayer.id("chests/buried_treasure"));
    private static final String[] DIRS = {"east", "south-east", "south", "south-west", "west", "north-west", "north", "north-east"};

    public TreasureMapItem(Properties props) { super(props); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!(level instanceof ServerLevel sl) || !(player instanceof ServerPlayer sp)) {
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
        }
        CustomData cd = stack.get(DataComponents.CUSTOM_DATA);
        CompoundTag tag = cd == null ? new CompoundTag() : cd.copyTag();
        if (!tag.contains("TX")) {
            double a = sp.getRandom().nextDouble() * Math.PI * 2;
            double d = 150 + sp.getRandom().nextInt(250);
            tag.putInt("TX", (int) (sp.getX() + Math.cos(a) * d));
            tag.putInt("TZ", (int) (sp.getZ() + Math.sin(a) * d));
            level.playSound(null, sp.blockPosition(), SoundEvents.BOOK_PAGE_TURN, SoundSource.PLAYERS, 1.0f, 1.0f);
        }
        int tx = tag.getInt("TX"), tz = tag.getInt("TZ");
        double dx = tx + 0.5 - sp.getX(), dz = tz + 0.5 - sp.getZ();
        double dist = Math.sqrt(dx * dx + dz * dz);

        if (tag.getBoolean("Dug")) {
            sp.displayClientMessage(Component.translatable("message.giantslayer.map_done"), true);
        } else if (dist < 6) {
            unearth(sl, sp, tx, tz);
            tag.putBoolean("Dug", true);
        } else {
            int idx = Math.floorMod((int) Math.round(Math.atan2(dz, dx) / (Math.PI / 4)), 8);
            sp.displayClientMessage(Component.translatable("message.giantslayer.map_hint", (int) dist, DIRS[idx])
                    .withStyle(ChatFormatting.GOLD), true);
        }
        stack.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
        return InteractionResultHolder.sidedSuccess(stack, false);
    }

    private static void unearth(ServerLevel sl, ServerPlayer sp, int tx, int tz) {
        int top = sl.getHeight(Heightmap.Types.OCEAN_FLOOR, tx, tz) - 1;
        BlockPos chest = new BlockPos(tx, top - 2, tz);
        sl.setBlock(chest, Blocks.CHEST.defaultBlockState(), 3);
        RandomizableContainer.setBlockEntityLootTable(sl, sp.getRandom(), chest, LOOT);
        if (StoryManager.get(sp).stage() == 17 && sl.getBlockEntity(chest) instanceof ChestBlockEntity be) {
            FruitType[] all = FruitType.values();
            be.setItem(13, new ItemStack(all[sp.getRandom().nextInt(all.length)].item()));
        }
        for (int i = -2; i <= 2; i++) {
            sl.setBlock(new BlockPos(tx + i, top, tz + i), Blocks.RED_WOOL.defaultBlockState(), 3);
            sl.setBlock(new BlockPos(tx + i, top, tz - i), Blocks.RED_WOOL.defaultBlockState(), 3);
        }
        sl.playSound(null, chest, SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 1.0f, 0.8f);
        sp.sendSystemMessage(Component.translatable("message.giantslayer.map_found").withStyle(ChatFormatting.GOLD));
        StoryManager.onTreasureFound(sp);
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext ctx, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.giantslayer.treasure_map").withStyle(ChatFormatting.GRAY));
    }
}
