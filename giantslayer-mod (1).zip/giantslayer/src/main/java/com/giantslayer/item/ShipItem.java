package com.giantslayer.item;

import com.giantslayer.entity.ShipEntity;
import com.giantslayer.registry.ModEntities;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;

/** Right-click on water to launch your ship. */
public class ShipItem extends Item {
    public ShipItem(Properties props) { super(props); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        BlockHitResult hit = getPlayerPOVHitResult(level, player, ClipContext.Fluid.ANY);
        if (hit.getType() != HitResult.Type.BLOCK) return InteractionResultHolder.pass(stack);

        ShipEntity ship = ModEntities.SHIP.get().create(level);
        if (ship == null) return InteractionResultHolder.fail(stack);
        ship.moveTo(hit.getLocation().x, hit.getLocation().y, hit.getLocation().z, player.getYRot(), 0f);
        if (!level.noCollision(ship, ship.getBoundingBox())) return InteractionResultHolder.fail(stack);

        if (!level.isClientSide) {
            level.addFreshEntity(ship);
            if (!player.getAbilities().instabuild) stack.shrink(1);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }
}
