package com.giantslayer.item;

import com.giantslayer.power.FruitType;
import com.giantslayer.power.PowerManager;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import java.util.List;

/** Eat to gain a permanent power (ability on G). Eating a second fruit is very bad for you. */
public class PowerFruitItem extends Item {
    public final FruitType type;

    public PowerFruitItem(FruitType type, Properties props) {
        super(props);
        this.type = type;
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity user) {
        ItemStack result = super.finishUsingItem(stack, level, user);
        if (!level.isClientSide && user instanceof ServerPlayer sp) PowerManager.eat(sp, type);
        return result;
    }

    @Override public boolean isFoil(ItemStack stack) { return true; }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext ctx, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("power.giantslayer." + type.id + ".desc").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.giantslayer.one_fruit").withStyle(ChatFormatting.DARK_RED));
    }
}
