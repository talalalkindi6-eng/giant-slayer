package com.giantslayer.item;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.item.TooltipFlag;

import java.util.List;

/** Light, sharp, brittle. The only weapon that kills a giant with one nape strike. */
public class SlayerBladeItem extends SwordItem {
    public SlayerBladeItem(Properties props) {
        this(Tiers.IRON, 4, props);
    }

    /** Used by upgraded blades (e.g. Ember Steel). Any SlayerBladeItem counts for nape kills. */
    public SlayerBladeItem(net.minecraft.world.item.Tier tier, int damage, Properties props) {
        super(tier, props.attributes(SwordItem.createAttributes(tier, damage, -2.0f)));
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext ctx, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.giantslayer.blade_help").withStyle(ChatFormatting.GRAY));
    }
}
