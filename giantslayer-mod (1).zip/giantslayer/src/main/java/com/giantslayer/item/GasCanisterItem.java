package com.giantslayer.item;

import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Right-click to fully refill the maneuver gear in your inventory. */
public class GasCanisterItem extends Item {
    public GasCanisterItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack canister = player.getItemInHand(hand);
        if (!level.isClientSide) {
            ItemStack gear = ManeuverGearItem.findGear(player);
            if (gear.isEmpty()) {
                player.displayClientMessage(Component.translatable("message.giantslayer.no_gear"), true);
                return InteractionResultHolder.fail(canister);
            }
            if (gear.getDamageValue() == 0) {
                player.displayClientMessage(Component.translatable("message.giantslayer.gas_full"), true);
                return InteractionResultHolder.fail(canister);
            }
            ManeuverGearItem.refill(gear);
            if (!player.getAbilities().instabuild) canister.shrink(1);
            level.playSound(null, player.blockPosition(), SoundEvents.FIRE_EXTINGUISH, SoundSource.PLAYERS, 0.6f, 1.6f);
            player.displayClientMessage(Component.translatable("message.giantslayer.refilled"), true);
        }
        return InteractionResultHolder.sidedSuccess(canister, level.isClientSide);
    }
}
