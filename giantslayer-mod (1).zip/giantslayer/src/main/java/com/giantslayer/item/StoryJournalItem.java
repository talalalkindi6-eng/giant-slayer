package com.giantslayer.item;

import com.giantslayer.entity.StoryNpc;
import com.giantslayer.registry.ModAttachments;
import com.giantslayer.story.CampBuilder;
import com.giantslayer.story.StoryManager;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import java.util.List;

/**
 * First use: founds the Ember Watch camp where you stand and starts the story.
 * After that: shows your current objective. Sneak-use re-founds the camp here
 * if no camp characters are within 128 blocks.
 */
public class StoryJournalItem extends Item {
    public StoryJournalItem(Properties props) { super(props); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide && player instanceof ServerPlayer sp) {
            var data = StoryManager.get(sp);
            boolean noNpcsNearby = sp.serverLevel().getEntitiesOfClass(StoryNpc.class,
                    sp.getBoundingBox().inflate(128)).isEmpty();
            if (!data.campBuilt() || (sp.isShiftKeyDown() && noNpcsNearby)) {
                CampBuilder.build(sp.serverLevel(), sp.blockPosition());
                sp.setData(ModAttachments.STORY, data.withCamp());
                level.playSound(null, sp.blockPosition(), SoundEvents.BELL_BLOCK, SoundSource.PLAYERS, 1.0f, 0.8f);
                sp.sendSystemMessage(Component.translatable("message.giantslayer.camp_built").withStyle(ChatFormatting.GOLD));
            }
            StoryManager.showObjective(sp);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext ctx, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.giantslayer.journal_help").withStyle(ChatFormatting.GRAY));
    }
}
