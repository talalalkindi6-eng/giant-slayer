package com.giantslayer.item;

import com.giantslayer.entity.projectile.ThunderLanceEntity;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import java.util.List;

/** Launch an explosive lance that sticks into its target and detonates 1.5s later. */
public class ThunderLanceItem extends Item {
    public ThunderLanceItem(Properties props) { super(props); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide) {
            ThunderLanceEntity lance = new ThunderLanceEntity(level, player);
            lance.shootFromRotation(player, player.getXRot(), player.getYRot(), 0.0f, 2.6f, 0.4f);
            level.addFreshEntity(lance);
            level.playSound(null, player.blockPosition(), SoundEvents.CROSSBOW_SHOOT, SoundSource.PLAYERS, 1.2f, 0.6f);
            if (!player.getAbilities().instabuild) stack.shrink(1);
        }
        player.getCooldowns().addCooldown(this, 20);
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext ctx, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.giantslayer.thunder_lance").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.giantslayer.thunder_lance2").withStyle(ChatFormatting.DARK_GRAY));
    }
}
