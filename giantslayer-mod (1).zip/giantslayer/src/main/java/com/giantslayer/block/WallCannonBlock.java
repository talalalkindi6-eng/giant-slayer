package com.giantslayer.block;

import com.giantslayer.entity.projectile.CannonballEntity;
import com.giantslayer.registry.ModItems;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Place it on your wall facing outward. Right-click it holding a Cannonball to fire
 * where you're looking (within the direction the cannon faces).
 */
public class WallCannonBlock extends HorizontalDirectionalBlock {
    public static final MapCodec<WallCannonBlock> CODEC = simpleCodec(WallCannonBlock::new);

    public WallCannonBlock(Properties props) {
        super(props);
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.NORTH));
    }

    @Override protected MapCodec<? extends HorizontalDirectionalBlock> codec() { return CODEC; }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        return defaultBlockState().setValue(FACING, ctx.getHorizontalDirection());
    }

    @Override
    protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos,
                                              Player player, InteractionHand hand, BlockHitResult hit) {
        if (!stack.is(ModItems.CANNONBALL.get())) return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        if (player.getCooldowns().isOnCooldown(stack.getItem())) return ItemInteractionResult.CONSUME;

        if (level instanceof ServerLevel sl) {
            Direction facing = state.getValue(FACING);
            Vec3 dir = player.getLookAngle();
            if (dir.dot(Vec3.atLowerCornerOf(facing.getNormal())) < 0.2) {
                dir = new Vec3(facing.getStepX(), 0.15, facing.getStepZ()).normalize();
            }
            CannonballEntity ball = new CannonballEntity(level,
                    pos.getX() + 0.5 + dir.x * 1.2, pos.getY() + 0.8 + dir.y, pos.getZ() + 0.5 + dir.z * 1.2);
            ball.setOwner(player);
            ball.shoot(dir.x, dir.y, dir.z, 3.2f, 0.5f);
            level.addFreshEntity(ball);

            level.playSound(null, pos, SoundEvents.GENERIC_EXPLODE.value(), SoundSource.BLOCKS, 1.5f, 1.4f);
            sl.sendParticles(ParticleTypes.LARGE_SMOKE, pos.getX() + 0.5 + dir.x, pos.getY() + 0.9, pos.getZ() + 0.5 + dir.z,
                    15, 0.2, 0.2, 0.2, 0.05);
            if (!player.getAbilities().instabuild) stack.shrink(1);
        }
        player.getCooldowns().addCooldown(stack.getItem(), 30);
        return ItemInteractionResult.sidedSuccess(level.isClientSide);
    }
}
