package com.giantslayer.registry;

import com.giantslayer.GiantSlayer;
import com.giantslayer.entity.*;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(Registries.ENTITY_TYPE, GiantSlayer.MODID);

    // Base sizes before each giant's random SCALE is applied. They match the renderer's body proportions.
    public static final DeferredHolder<EntityType<?>, EntityType<GiantEntity>> GIANT =
            giant("giant", GiantEntity::new, 0.9f, 4.0f);
    public static final DeferredHolder<EntityType<?>, EntityType<SprinterGiant>> SPRINTER =
            giant("sprinter_giant", SprinterGiant::new, 0.75f, 4.8f);
    public static final DeferredHolder<EntityType<?>, EntityType<LeaperGiant>> LEAPER =
            giant("leaper_giant", LeaperGiant::new, 0.9f, 3.8f);
    public static final DeferredHolder<EntityType<?>, EntityType<HowlerGiant>> HOWLER =
            giant("howler_giant", HowlerGiant::new, 1.0f, 4.0f);
    public static final DeferredHolder<EntityType<?>, EntityType<BurrowerGiant>> BURROWER =
            giant("burrower_giant", BurrowerGiant::new, 1.1f, 3.6f);
    public static final DeferredHolder<EntityType<?>, EntityType<BroodGiant>> BROOD =
            giant("brood_giant", BroodGiant::new, 1.2f, 4.0f);

    public static final DeferredHolder<EntityType<?>, EntityType<StoryNpc>> STORY_NPC = ENTITY_TYPES.register("story_npc",
            () -> EntityType.Builder.of(StoryNpc::new, MobCategory.MISC).sized(0.6f, 1.95f).clientTrackingRange(10).build("story_npc"));

    public static final DeferredHolder<EntityType<?>, EntityType<com.giantslayer.entity.projectile.ThunderLanceEntity>> THUNDER_LANCE =
            ENTITY_TYPES.register("thunder_lance", () -> EntityType.Builder.<com.giantslayer.entity.projectile.ThunderLanceEntity>of(
                    com.giantslayer.entity.projectile.ThunderLanceEntity::new, MobCategory.MISC)
                    .sized(0.3f, 0.3f).clientTrackingRange(8).updateInterval(5).build("thunder_lance"));
    public static final DeferredHolder<EntityType<?>, EntityType<com.giantslayer.entity.projectile.FlareEntity>> FLARE =
            ENTITY_TYPES.register("flare", () -> EntityType.Builder.<com.giantslayer.entity.projectile.FlareEntity>of(
                    com.giantslayer.entity.projectile.FlareEntity::new, MobCategory.MISC)
                    .sized(0.25f, 0.25f).clientTrackingRange(16).updateInterval(5).build("flare"));
    public static final DeferredHolder<EntityType<?>, EntityType<com.giantslayer.entity.projectile.CannonballEntity>> CANNONBALL =
            ENTITY_TYPES.register("cannonball", () -> EntityType.Builder.<com.giantslayer.entity.projectile.CannonballEntity>of(
                    com.giantslayer.entity.projectile.CannonballEntity::new, MobCategory.MISC)
                    .sized(0.4f, 0.4f).clientTrackingRange(10).updateInterval(5).build("cannonball"));

    public static final DeferredHolder<EntityType<?>, EntityType<ShipEntity>> SHIP = ENTITY_TYPES.register("ship",
            () -> EntityType.Builder.<ShipEntity>of(ShipEntity::new, MobCategory.MISC)
                    .sized(3.0f, 1.0f).clientTrackingRange(10).build("ship"));
    public static final DeferredHolder<EntityType<?>, EntityType<PirateEntity>> PIRATE = ENTITY_TYPES.register("pirate",
            () -> EntityType.Builder.<PirateEntity>of(PirateEntity::new, MobCategory.MONSTER)
                    .sized(0.6f, 1.95f).clientTrackingRange(8).build("pirate"));
    public static final DeferredHolder<EntityType<?>, EntityType<PirateCaptainEntity>> PIRATE_CAPTAIN = ENTITY_TYPES.register("pirate_captain",
            () -> EntityType.Builder.<PirateCaptainEntity>of(PirateCaptainEntity::new, MobCategory.MONSTER)
                    .sized(0.7f, 2.15f).clientTrackingRange(10).build("pirate_captain"));

    private static <T extends GiantEntity> DeferredHolder<EntityType<?>, EntityType<T>> giant(
            String name, EntityType.EntityFactory<T> factory, float width, float height) {
        return ENTITY_TYPES.register(name, () -> EntityType.Builder.of(factory, MobCategory.MONSTER)
                .sized(width, height).clientTrackingRange(16).build(name));
    }
}
