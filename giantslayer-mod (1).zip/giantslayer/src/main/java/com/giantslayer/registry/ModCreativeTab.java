package com.giantslayer.registry;

import com.giantslayer.GiantSlayer;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModCreativeTab {
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, GiantSlayer.MODID);

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MAIN = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.giantslayer"))
                    .icon(() -> new ItemStack(ModItems.MANEUVER_GEAR.get()))
                    .displayItems((params, out) -> {
                        out.accept(ModItems.STORY_JOURNAL.get());
                        out.accept(ModItems.MANEUVER_GEAR.get());
                        out.accept(ModItems.GAS_CANISTER.get());
                        out.accept(ModItems.SLAYER_BLADE.get());
                        out.accept(ModItems.EMBER_BLADE.get());
                        out.accept(ModItems.THUNDER_LANCE.get());
                        out.accept(ModItems.FLARE_PISTOL.get());
                        out.accept(ModItems.GREEN_FLARE.get());
                        out.accept(ModItems.RED_FLARE.get());
                        out.accept(ModItems.BLACK_FLARE.get());
                        out.accept(ModItems.SCOUT_CLOAK.get());
                        out.accept(ModItems.SCOUT_RATION.get());
                        out.accept(ModItems.WALL_CANNON.get());
                        out.accept(ModItems.CANNONBALL.get());
                        out.accept(ModItems.WALL_CHARTER.get());
                        out.accept(ModItems.SHIP.get());
                        out.accept(ModItems.TREASURE_MAP.get());
                        out.accept(ModItems.CUTLASS.get());
                        out.accept(ModItems.GALE_FRUIT.get());
                        out.accept(ModItems.STONEHIDE_FRUIT.get());
                        out.accept(ModItems.THORNVINE_FRUIT.get());
                        out.accept(ModItems.BLINK_FRUIT.get());
                        out.accept(ModItems.TIDE_FRUIT.get());
                        out.accept(ModItems.COLOSSUS_FRUIT.get());
                        out.accept(ModItems.PIRATE_SPAWN_EGG.get());
                        out.accept(ModItems.PIRATE_CAPTAIN_SPAWN_EGG.get());
                        out.accept(ModItems.WALL_STONE.get());
                        out.accept(ModItems.GIANT_SPAWN_EGG.get());
                        out.accept(ModItems.SPRINTER_SPAWN_EGG.get());
                        out.accept(ModItems.LEAPER_SPAWN_EGG.get());
                        out.accept(ModItems.HOWLER_SPAWN_EGG.get());
                        out.accept(ModItems.BURROWER_SPAWN_EGG.get());
                        out.accept(ModItems.BROOD_SPAWN_EGG.get());
                    })
                    .build());
}
