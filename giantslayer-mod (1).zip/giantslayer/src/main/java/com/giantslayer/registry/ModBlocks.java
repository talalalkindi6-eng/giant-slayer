package com.giantslayer.registry;

import com.giantslayer.GiantSlayer;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModBlocks {
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(GiantSlayer.MODID);

    /** Extremely tough stone used for the great walls. */
    public static final DeferredBlock<Block> WALL_STONE = BLOCKS.registerSimpleBlock("wall_stone",
            BlockBehaviour.Properties.of().mapColor(MapColor.STONE).strength(6.0f, 1200.0f)
                    .requiresCorrectToolForDrops().sound(SoundType.STONE));

    public static final DeferredBlock<com.giantslayer.block.WallCannonBlock> WALL_CANNON = BLOCKS.register("wall_cannon",
            () -> new com.giantslayer.block.WallCannonBlock(BlockBehaviour.Properties.of().mapColor(MapColor.METAL)
                    .strength(5.0f, 12.0f).requiresCorrectToolForDrops().sound(SoundType.METAL).noOcclusion()));
}
