package com.giantslayer.registry;

import com.giantslayer.GiantSlayer;
import net.minecraft.Util;
import net.minecraft.core.registries.Registries;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.EnumMap;
import java.util.List;

public class ModArmorMaterials {
    public static final DeferredRegister<ArmorMaterial> MATERIALS =
            DeferredRegister.create(Registries.ARMOR_MATERIAL, GiantSlayer.MODID);

    public static final DeferredHolder<ArmorMaterial, ArmorMaterial> SCOUT = MATERIALS.register("scout",
            () -> new ArmorMaterial(
                    Util.make(new EnumMap<>(ArmorItem.Type.class), m -> {
                        m.put(ArmorItem.Type.BOOTS, 1);
                        m.put(ArmorItem.Type.LEGGINGS, 2);
                        m.put(ArmorItem.Type.CHESTPLATE, 4);
                        m.put(ArmorItem.Type.HELMET, 1);
                        m.put(ArmorItem.Type.BODY, 4);
                    }),
                    15, SoundEvents.ARMOR_EQUIP_LEATHER, () -> Ingredient.of(Items.LEATHER),
                    List.of(new ArmorMaterial.Layer(GiantSlayer.id("scout"))), 0.0f, 0.0f));
}
