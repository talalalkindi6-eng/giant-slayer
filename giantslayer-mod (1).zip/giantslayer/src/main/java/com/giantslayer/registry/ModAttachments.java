package com.giantslayer.registry;

import com.giantslayer.GiantSlayer;
import com.giantslayer.story.StoryData;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

import java.util.function.Supplier;

public class ModAttachments {
    public static final DeferredRegister<AttachmentType<?>> ATTACHMENTS =
            DeferredRegister.create(NeoForgeRegistries.ATTACHMENT_TYPES, GiantSlayer.MODID);

    public static final Supplier<AttachmentType<StoryData>> STORY = ATTACHMENTS.register("story",
            () -> AttachmentType.builder(() -> StoryData.EMPTY).serialize(StoryData.CODEC).copyOnDeath().build());

    /** Which power fruit this player has eaten ("" = none). */
    public static final Supplier<AttachmentType<String>> POWER = ATTACHMENTS.register("power",
            () -> AttachmentType.builder(() -> "").serialize(com.mojang.serialization.Codec.STRING).copyOnDeath().build());
}
