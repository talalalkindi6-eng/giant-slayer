package com.giantslayer.registry;

import com.giantslayer.GiantSlayer;
import com.giantslayer.world.WallRuinFeature;
import com.giantslayer.world.WatchtowerFeature;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModFeatures {
    public static final DeferredRegister<Feature<?>> FEATURES = DeferredRegister.create(Registries.FEATURE, GiantSlayer.MODID);

    public static final DeferredHolder<Feature<?>, WatchtowerFeature> WATCHTOWER =
            FEATURES.register("watchtower", () -> new WatchtowerFeature(NoneFeatureConfiguration.CODEC));

    public static final DeferredHolder<Feature<?>, com.giantslayer.world.IslandFeature> ISLAND =
            FEATURES.register("island", () -> new com.giantslayer.world.IslandFeature(NoneFeatureConfiguration.CODEC));

    public static final DeferredHolder<Feature<?>, WallRuinFeature> WALL_RUIN =
            FEATURES.register("wall_ruin", () -> new WallRuinFeature(NoneFeatureConfiguration.CODEC));
}
