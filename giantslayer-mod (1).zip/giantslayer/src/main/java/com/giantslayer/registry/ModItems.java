package com.giantslayer.registry;

import com.giantslayer.GiantSlayer;
import com.giantslayer.item.*;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(GiantSlayer.MODID);

    public static final DeferredItem<ManeuverGearItem> MANEUVER_GEAR = ITEMS.register("maneuver_gear",
            () -> new ManeuverGearItem(new Item.Properties().durability(ManeuverGearItem.MAX_GAS)));

    public static final DeferredItem<GasCanisterItem> GAS_CANISTER = ITEMS.register("gas_canister",
            () -> new GasCanisterItem(new Item.Properties().stacksTo(16)));

    public static final DeferredItem<SlayerBladeItem> SLAYER_BLADE = ITEMS.register("slayer_blade",
            () -> new SlayerBladeItem(new Item.Properties()));

    public static final DeferredItem<WallCharterItem> WALL_CHARTER = ITEMS.register("wall_charter",
            () -> new WallCharterItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC)));

    public static final DeferredItem<StoryJournalItem> STORY_JOURNAL = ITEMS.register("story_journal",
            () -> new StoryJournalItem(new Item.Properties().stacksTo(1).rarity(Rarity.UNCOMMON)));

    // --- Field equipment ---
    public static final DeferredItem<ThunderLanceItem> THUNDER_LANCE = ITEMS.register("thunder_lance",
            () -> new ThunderLanceItem(new Item.Properties().stacksTo(8)));
    public static final DeferredItem<FlarePistolItem> FLARE_PISTOL = ITEMS.register("flare_pistol",
            () -> new FlarePistolItem(new Item.Properties().durability(250)));
    public static final DeferredItem<FlareItem> GREEN_FLARE = ITEMS.register("green_flare",
            () -> new FlareItem(FlareColor.GREEN, new Item.Properties().stacksTo(16)));
    public static final DeferredItem<FlareItem> RED_FLARE = ITEMS.register("red_flare",
            () -> new FlareItem(FlareColor.RED, new Item.Properties().stacksTo(16)));
    public static final DeferredItem<FlareItem> BLACK_FLARE = ITEMS.register("black_flare",
            () -> new FlareItem(FlareColor.BLACK, new Item.Properties().stacksTo(16)));
    public static final DeferredItem<net.minecraft.world.item.ArmorItem> SCOUT_CLOAK = ITEMS.register("scout_cloak",
            () -> new net.minecraft.world.item.ArmorItem(ModArmorMaterials.SCOUT, net.minecraft.world.item.ArmorItem.Type.CHESTPLATE,
                    new Item.Properties().durability(net.minecraft.world.item.ArmorItem.Type.CHESTPLATE.getDurability(15))));
    public static final DeferredItem<SlayerBladeItem> EMBER_BLADE = ITEMS.register("ember_blade",
            () -> new SlayerBladeItem(net.minecraft.world.item.Tiers.DIAMOND, 5, new Item.Properties().rarity(Rarity.RARE)));
    public static final DeferredItem<Item> SCOUT_RATION = ITEMS.registerSimpleItem("scout_ration",
            new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder()
                    .nutrition(7).saturationModifier(0.9f).build()));
    public static final DeferredItem<Item> CANNONBALL = ITEMS.registerSimpleItem("cannonball", new Item.Properties().stacksTo(16));
    public static final DeferredItem<BlockItem> WALL_CANNON = ITEMS.registerSimpleBlockItem("wall_cannon", ModBlocks.WALL_CANNON);

    // --- Seas & power fruits ---
    public static final DeferredItem<PowerFruitItem> GALE_FRUIT = fruit("gale_fruit", com.giantslayer.power.FruitType.GALE);
    public static final DeferredItem<PowerFruitItem> STONEHIDE_FRUIT = fruit("stonehide_fruit", com.giantslayer.power.FruitType.STONEHIDE);
    public static final DeferredItem<PowerFruitItem> THORNVINE_FRUIT = fruit("thornvine_fruit", com.giantslayer.power.FruitType.THORNVINE);
    public static final DeferredItem<PowerFruitItem> BLINK_FRUIT = fruit("blink_fruit", com.giantslayer.power.FruitType.BLINK);
    public static final DeferredItem<PowerFruitItem> TIDE_FRUIT = fruit("tide_fruit", com.giantslayer.power.FruitType.TIDE);
    public static final DeferredItem<PowerFruitItem> COLOSSUS_FRUIT = fruit("colossus_fruit", com.giantslayer.power.FruitType.COLOSSUS);

    public static final DeferredItem<ShipItem> SHIP = ITEMS.register("ship", () -> new ShipItem(new Item.Properties().stacksTo(1)));
    public static final DeferredItem<TreasureMapItem> TREASURE_MAP = ITEMS.register("treasure_map",
            () -> new TreasureMapItem(new Item.Properties().stacksTo(1).rarity(Rarity.UNCOMMON)));
    public static final DeferredItem<net.minecraft.world.item.SwordItem> CUTLASS = ITEMS.register("cutlass",
            () -> new net.minecraft.world.item.SwordItem(net.minecraft.world.item.Tiers.IRON, new Item.Properties()
                    .attributes(net.minecraft.world.item.SwordItem.createAttributes(net.minecraft.world.item.Tiers.IRON, 4, -2.2f))));
    public static final DeferredItem<DeferredSpawnEggItem> PIRATE_SPAWN_EGG = ITEMS.register("pirate_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.PIRATE, 0x3A2A20, 0xB02020, new Item.Properties()));
    public static final DeferredItem<DeferredSpawnEggItem> PIRATE_CAPTAIN_SPAWN_EGG = ITEMS.register("pirate_captain_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.PIRATE_CAPTAIN, 0x15151A, 0xC8D8F0, new Item.Properties()));

    private static DeferredItem<PowerFruitItem> fruit(String name, com.giantslayer.power.FruitType type) {
        return ITEMS.register(name, () -> new PowerFruitItem(type, new Item.Properties().stacksTo(1).rarity(Rarity.EPIC)
                .food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(2).saturationModifier(0.3f).alwaysEdible().build())));
    }

    public static final DeferredItem<BlockItem> WALL_STONE = ITEMS.registerSimpleBlockItem("wall_stone", ModBlocks.WALL_STONE);

    public static final DeferredItem<DeferredSpawnEggItem> GIANT_SPAWN_EGG = ITEMS.register("giant_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.GIANT, 0xC9A27E, 0x5A2E1E, new Item.Properties()));
    public static final DeferredItem<DeferredSpawnEggItem> SPRINTER_SPAWN_EGG = ITEMS.register("sprinter_giant_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.SPRINTER, 0xAAB4A0, 0x2A2A2A, new Item.Properties()));
    public static final DeferredItem<DeferredSpawnEggItem> LEAPER_SPAWN_EGG = ITEMS.register("leaper_giant_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.LEAPER, 0xC47860, 0xE07A20, new Item.Properties()));
    public static final DeferredItem<DeferredSpawnEggItem> HOWLER_SPAWN_EGG = ITEMS.register("howler_giant_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.HOWLER, 0x788296, 0x1A1A22, new Item.Properties()));
    public static final DeferredItem<DeferredSpawnEggItem> BURROWER_SPAWN_EGG = ITEMS.register("burrower_giant_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.BURROWER, 0x826950, 0x4A3A28, new Item.Properties()));
    public static final DeferredItem<DeferredSpawnEggItem> BROOD_SPAWN_EGG = ITEMS.register("brood_giant_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.BROOD, 0xDCAAAA, 0xF0F0E6, new Item.Properties()));
}
