package com.giantslayer.world;

import com.giantslayer.registry.ModBlocks;
import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/** A crumbling fragment of some ancient wall, overgrown and broken. */
public class WallRuinFeature extends Feature<NoneFeatureConfiguration> {
    public WallRuinFeature(Codec<NoneFeatureConfiguration> codec) {
        super(codec);
    }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
        WorldGenLevel level = ctx.level();
        BlockPos origin = ctx.origin();
        RandomSource r = ctx.random();
        if (!WatchtowerFeature.solidGround(level, origin)) return false;

        boolean alongX = r.nextBoolean();
        int half = 5 + r.nextInt(3);
        int baseH = 6 + r.nextInt(9);
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();

        for (int i = -half; i <= half; i++) {
            for (int t = -1; t <= 1; t++) {
                int x = origin.getX() + (alongX ? i : t);
                int z = origin.getZ() + (alongX ? t : i);
                int ground = level.getHeight(net.minecraft.world.level.levelgen.Heightmap.Types.WORLD_SURFACE_WG, x, z);
                WatchtowerFeature.foundation(level, x, ground, z, r);
                int edgeLoss = Math.abs(i) > half - 3 ? r.nextInt(6) : 0;
                int h = Math.max(1, baseH - r.nextInt(3) - edgeLoss);
                for (int y = 0; y < h; y++) {
                    p.set(x, ground + y, z);
                    level.setBlock(p, pick(r), 2);
                }
            }
        }
        // Rubble on the ground nearby.
        for (int i = 0; i < 8; i++) {
            int x = origin.getX() + r.nextInt(9) - 4;
            int z = origin.getZ() + r.nextInt(9) - 4;
            int y = level.getHeight(net.minecraft.world.level.levelgen.Heightmap.Types.WORLD_SURFACE_WG, x, z);
            p.set(x, y, z);
            if (level.getBlockState(p).isAir()) level.setBlock(p, Blocks.COBBLESTONE.defaultBlockState(), 2);
        }
        return true;
    }

    private static BlockState pick(RandomSource r) {
        int n = r.nextInt(10);
        if (n < 6) return ModBlocks.WALL_STONE.get().defaultBlockState();
        if (n < 8) return Blocks.MOSSY_COBBLESTONE.defaultBlockState();
        return Blocks.CRACKED_STONE_BRICKS.defaultBlockState();
    }
}
