package com.giantslayer.world;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.IntArrayTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.ArrayList;
import java.util.List;

/** Remembers every wall ring that was built so giants never spawn inside one. */
public class WallZones extends SavedData {
    private final List<int[]> zones = new ArrayList<>();

    public static WallZones get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(
                new SavedData.Factory<>(WallZones::new, WallZones::load, null), "giantslayer_walls");
    }

    private static WallZones load(CompoundTag tag, HolderLookup.Provider provider) {
        WallZones data = new WallZones();
        ListTag list = tag.getList("zones", Tag.TAG_INT_ARRAY);
        for (int i = 0; i < list.size(); i++) data.zones.add(list.getIntArray(i));
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider provider) {
        ListTag list = new ListTag();
        for (int[] z : zones) list.add(new IntArrayTag(z));
        tag.put("zones", list);
        return tag;
    }

    public void add(int cx, int cz, int radius) {
        zones.add(new int[]{cx, cz, radius});
        setDirty();
    }

    public boolean isProtected(BlockPos pos) {
        for (int[] z : zones) {
            long dx = pos.getX() - z[0], dz = pos.getZ() - z[1];
            long r = z[2] - 4;
            if (dx * dx + dz * dz < r * r) return true;
        }
        return false;
    }
}
