package com.giantslayer.world;

import com.giantslayer.GiantSlayer;
import com.giantslayer.entity.PirateEntity;
import com.giantslayer.registry.ModEntities;
import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.entity.RandomizableContainer;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;
import net.minecraft.world.level.storage.loot.LootTable;

/** A small pirate island: sand, palms, a corsair camp, two pirates and a chest buried under a red X. */
public class IslandFeature extends Feature<NoneFeatureConfiguration> {
    private static final int R = 7;
    public static final ResourceKey<LootTable> LOOT =
            ResourceKey.create(Registries.LOOT_TABLE, GiantSlayer.id("chests/island_treasure"));

    public IslandFeature(Codec<NoneFeatureConfiguration> codec) { super(codec); }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
        WorldGenLevel level = ctx.level();
        BlockPos origin = ctx.origin();
        RandomSource r = ctx.random();
        int sea = level.getSeaLevel();
        if (!level.getFluidState(origin).is(FluidTags.WATER)) return false;
        int depth = sea - origin.getY();
        if (depth < 1 || depth > 22) return false;

        int top = sea + 2;
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        for (int dx = -R; dx <= R; dx++) {
            for (int dz = -R; dz <= R; dz++) {
                double d = Math.sqrt(dx * dx + dz * dz) + r.nextDouble() * 0.6;
                if (d > R) continue;
                int colTop = d < R - 2.5 ? top : d < R - 1 ? top - 1 : sea;
                int x = origin.getX() + dx, z = origin.getZ() + dz;
                int floor = level.getHeight(Heightmap.Types.OCEAN_FLOOR_WG, x, z);
                for (int y = Math.min(floor, sea) - 1; y <= colTop; y++) {
                    p.set(x, y, z);
                    level.setBlock(p, y > colTop - 3 ? Blocks.SAND.defaultBlockState() : Blocks.SANDSTONE.defaultBlockState(), 2);
                }
            }
        }

        palm(level, origin.offset(3, 0, 2).atY(top + 1), r);
        palm(level, origin.offset(-4, 0, 1).atY(top + 1), r);

        // Corsair camp
        level.setBlock(origin.offset(-2, 0, -3).atY(top + 1), Blocks.CAMPFIRE.defaultBlockState(), 2);
        level.setBlock(origin.offset(2, 0, -3).atY(top + 1), Blocks.BARREL.defaultBlockState(), 2);

        // Buried treasure under a red X
        BlockPos chest = origin.atY(top - 2);
        level.setBlock(chest, Blocks.CHEST.defaultBlockState(), 2);
        RandomizableContainer.setBlockEntityLootTable(level, r, chest, LOOT);
        for (int i = -1; i <= 1; i++) {
            level.setBlock(origin.offset(i, 0, i).atY(top), Blocks.RED_TERRACOTTA.defaultBlockState(), 2);
            level.setBlock(origin.offset(i, 0, -i).atY(top), Blocks.RED_TERRACOTTA.defaultBlockState(), 2);
        }

        // Two corsairs guarding it
        for (int i = 0; i < 2; i++) {
            PirateEntity pirate = ModEntities.PIRATE.get().create(level.getLevel());
            if (pirate == null) continue;
            BlockPos at = origin.offset(i == 0 ? 1 : -1, 0, 3).atY(top + 1);
            pirate.moveTo(at.getX() + 0.5, at.getY(), at.getZ() + 0.5, r.nextFloat() * 360f, 0f);
            pirate.finalizeSpawn(level, level.getCurrentDifficultyAt(at), MobSpawnType.STRUCTURE, null);
            pirate.setPersistenceRequired();
            level.addFreshEntity(pirate);
        }
        return true;
    }

    private static void palm(WorldGenLevel level, BlockPos base, RandomSource r) {
        int h = 5 + r.nextInt(2);
        for (int y = 0; y < h; y++) level.setBlock(base.above(y), Blocks.JUNGLE_LOG.defaultBlockState(), 2);
        BlockState leaves = Blocks.JUNGLE_LEAVES.defaultBlockState().setValue(LeavesBlock.PERSISTENT, true);
        BlockPos crown = base.above(h);
        level.setBlock(crown, leaves, 2);
        int[][] arms = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
        for (int[] a : arms) {
            for (int i = 1; i <= 3; i++) {
                level.setBlock(crown.offset(a[0] * i, i == 3 ? -1 : 0, a[1] * i), leaves, 2);
            }
        }
    }
}
