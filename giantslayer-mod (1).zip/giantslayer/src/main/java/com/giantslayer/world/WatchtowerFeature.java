package com.giantslayer.world;

import com.giantslayer.GiantSlayer;
import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LadderBlock;
import net.minecraft.world.level.block.entity.RandomizableContainer;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;
import net.minecraft.world.level.storage.loot.LootTable;

/** A ruined scout watchtower with a ladder and a supply chest (gas, blades, food). */
public class WatchtowerFeature extends Feature<NoneFeatureConfiguration> {
    public static final ResourceKey<LootTable> LOOT =
            ResourceKey.create(Registries.LOOT_TABLE, GiantSlayer.id("chests/watchtower"));

    public WatchtowerFeature(Codec<NoneFeatureConfiguration> codec) {
        super(codec);
    }

    static BlockState brick(RandomSource r) {
        int n = r.nextInt(10);
        if (n < 6) return Blocks.STONE_BRICKS.defaultBlockState();
        if (n < 8) return Blocks.MOSSY_STONE_BRICKS.defaultBlockState();
        return Blocks.CRACKED_STONE_BRICKS.defaultBlockState();
    }

    static boolean solidGround(WorldGenLevel level, BlockPos origin) {
        BlockPos below = origin.below();
        BlockState s = level.getBlockState(below);
        return level.getFluidState(below).isEmpty() && level.getFluidState(origin).isEmpty()
                && s.isFaceSturdy(level, below, Direction.UP) && !s.is(BlockTags.LEAVES);
    }

    static void foundation(WorldGenLevel level, int x, int y, int z, RandomSource r) {
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos(x, y - 1, z);
        for (int i = 0; i < 10 && p.getY() > level.getMinBuildHeight(); i++) {
            BlockState cur = level.getBlockState(p);
            if (cur.isFaceSturdy(level, p, Direction.UP) && !cur.is(BlockTags.LEAVES) && !cur.is(BlockTags.LOGS)) break;
            level.setBlock(p, brick(r), 2);
            p.move(Direction.DOWN);
        }
    }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
        WorldGenLevel level = ctx.level();
        BlockPos origin = ctx.origin();
        RandomSource r = ctx.random();
        if (!solidGround(level, origin)) return false;

        // Skip steep terrain.
        int min = Integer.MAX_VALUE, max = Integer.MIN_VALUE;
        for (int dx = -2; dx <= 2; dx += 4) for (int dz = -2; dz <= 2; dz += 4) {
            int h = level.getHeight(Heightmap.Types.WORLD_SURFACE_WG, origin.getX() + dx, origin.getZ() + dz);
            min = Math.min(min, h); max = Math.max(max, h);
        }
        if (max - min > 4) return false;

        int ox = origin.getX(), oy = origin.getY(), oz = origin.getZ();
        int h = 12 + r.nextInt(6);
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        BlockState ladder = Blocks.LADDER.defaultBlockState().setValue(LadderBlock.FACING, Direction.SOUTH);

        for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) foundation(level, ox + dx, oy, oz + dz, r);

        for (int y = 0; y < h; y++) {
            for (int dx = -2; dx <= 2; dx++) {
                for (int dz = -2; dz <= 2; dz++) {
                    p.set(ox + dx, oy + y, oz + dz);
                    boolean edge = Math.abs(dx) == 2 || Math.abs(dz) == 2;
                    boolean door = dz == 2 && dx == 0 && y < 2;
                    boolean window = y % 5 == 3 && (dx == 0 || dz == 0);
                    if (edge && !door && !window) level.setBlock(p, brick(r), 2);
                    else if (dx == 0 && dz == -1) level.setBlock(p, ladder, 2);
                    else level.setBlock(p, Blocks.AIR.defaultBlockState(), 2);
                }
            }
        }

        // Lookout platform with battlements.
        int top = oy + h;
        for (int dx = -3; dx <= 3; dx++) {
            for (int dz = -3; dz <= 3; dz++) {
                p.set(ox + dx, top, oz + dz);
                level.setBlock(p, (dx == 0 && dz == -1) ? ladder : brick(r), 2);
                boolean rim = Math.abs(dx) == 3 || Math.abs(dz) == 3;
                p.set(ox + dx, top + 1, oz + dz);
                level.setBlock(p, rim && ((dx + dz) & 1) == 0 ? brick(r) : Blocks.AIR.defaultBlockState(), 2);
                p.set(ox + dx, top + 2, oz + dz);
                level.setBlock(p, Blocks.AIR.defaultBlockState(), 2);
            }
        }

        BlockPos chestPos = new BlockPos(ox + 1, top + 1, oz + 1);
        level.setBlock(chestPos, Blocks.CHEST.defaultBlockState(), 2);
        RandomizableContainer.setBlockEntityLootTable(level, r, chestPos, LOOT);
        level.setBlock(new BlockPos(ox - 1, top + 1, oz + 1), Blocks.LANTERN.defaultBlockState(), 2);
        return true;
    }
}
