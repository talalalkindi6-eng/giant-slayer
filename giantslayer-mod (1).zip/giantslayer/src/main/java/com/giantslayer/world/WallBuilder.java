package com.giantslayer.world;

import com.giantslayer.GiantSlayer;
import com.giantslayer.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import org.jetbrains.annotations.Nullable;

import java.util.*;

/** Builds giant ring walls a few columns per tick so the server never freezes. */
@EventBusSubscriber(modid = GiantSlayer.MODID)
public class WallBuilder {
    private static final int THICKNESS = 4;
    private static final int GATE_HALF_WIDTH = 3;
    private static final int GATE_HEIGHT = 9;
    private static final int COLUMNS_PER_TICK = 48;

    private record Column(int x, int z, boolean gate, boolean outer) {}

    private static class Job {
        ServerLevel level;
        List<Column> columns;
        int index;
        int baseY, topY;
        @Nullable UUID owner;
    }

    private static final List<Job> JOBS = new ArrayList<>();

    public static void start(ServerLevel level, BlockPos center, int radius, int height, Direction gateDir, @Nullable Player owner) {
        List<Column> cols = new ArrayList<>();
        int gx = gateDir.getStepX(), gz = gateDir.getStepZ();
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d > radius || d <= radius - THICKNESS) continue;
                double along = dx * gx + dz * gz;
                double across = Math.abs(dx * gz - dz * gx);
                boolean gate = along > 0 && across <= GATE_HALF_WIDTH;
                boolean outer = d > radius - 1;
                cols.add(new Column(center.getX() + dx, center.getZ() + dz, gate, outer));
            }
        }
        // Sweep around the circle so it visibly rises section by section.
        cols.sort(Comparator.comparingDouble(c -> Math.atan2(c.z() - center.getZ(), c.x() - center.getX())));

        Job job = new Job();
        job.level = level;
        job.columns = cols;
        job.baseY = center.getY();
        job.topY = center.getY() + height;
        job.owner = owner == null ? null : owner.getUUID();
        JOBS.add(job);

        WallZones.get(level).add(center.getX(), center.getZ(), radius);
        if (owner != null) owner.displayClientMessage(Component.translatable("message.giantslayer.wall_start"), false);
    }

    @SubscribeEvent
    public static void onServerTick(ServerTickEvent.Post event) {
        Iterator<Job> it = JOBS.iterator();
        while (it.hasNext()) {
            Job job = it.next();
            int end = Math.min(job.index + COLUMNS_PER_TICK, job.columns.size());
            for (; job.index < end; job.index++) buildColumn(job, job.columns.get(job.index));

            ServerPlayer owner = job.owner == null ? null : job.level.getServer().getPlayerList().getPlayer(job.owner);
            if (job.index >= job.columns.size()) {
                it.remove();
                if (owner != null) {
                    owner.displayClientMessage(Component.translatable("message.giantslayer.wall_done"), false);
                    com.giantslayer.story.StoryManager.onWallBuilt(owner);
                }
            } else if (owner != null && job.level.getGameTime() % 20 == 0) {
                int pct = job.index * 100 / job.columns.size();
                owner.displayClientMessage(Component.translatable("message.giantslayer.wall_progress", pct), true);
            }
        }
    }

    private static void buildColumn(Job job, Column c) {
        ServerLevel level = job.level;
        BlockState wall = ModBlocks.WALL_STONE.get().defaultBlockState();
        BlockState air = Blocks.AIR.defaultBlockState();
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();

        int ground = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, c.x(), c.z());
        int bottom = Math.max(level.getMinBuildHeight(), Math.min(ground, job.baseY) - 4);
        int top = Math.min(level.getMaxBuildHeight() - 2, job.topY);

        for (int y = bottom; y <= top; y++) {
            pos.set(c.x(), y, c.z());
            boolean gateHole = c.gate() && y >= job.baseY && y < job.baseY + GATE_HEIGHT;
            level.setBlock(pos, gateHole ? air : wall, 2);
        }
        // Battlements on the outer rim.
        if (c.outer() && ((c.x() + c.z()) & 1) == 0) {
            level.setBlock(pos.set(c.x(), top + 1, c.z()), wall, 2);
        }
    }
}
