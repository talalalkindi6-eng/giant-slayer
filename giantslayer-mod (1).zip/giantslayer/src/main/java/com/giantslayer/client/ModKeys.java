package com.giantslayer.client;

import com.giantslayer.GiantSlayer;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import org.lwjgl.glfw.GLFW;

@EventBusSubscriber(modid = GiantSlayer.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ModKeys {
    public static final KeyMapping HOOK = new KeyMapping("key.giantslayer.hook",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_R, "key.categories.giantslayer");
    public static final KeyMapping BOOST = new KeyMapping("key.giantslayer.boost",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_V, "key.categories.giantslayer");

    public static final KeyMapping POWER = new KeyMapping("key.giantslayer.power",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_G, "key.categories.giantslayer");
    public static final KeyMapping BROADSIDE = new KeyMapping("key.giantslayer.broadside",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_B, "key.categories.giantslayer");

    @SubscribeEvent
    public static void register(RegisterKeyMappingsEvent event) {
        event.register(HOOK);
        event.register(BOOST);
        event.register(POWER);
        event.register(BROADSIDE);
    }
}
