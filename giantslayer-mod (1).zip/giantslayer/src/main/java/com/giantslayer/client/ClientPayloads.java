package com.giantslayer.client;

import com.giantslayer.network.DialoguePayload;
import com.giantslayer.story.NpcCharacter;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

public class ClientPayloads {
    public static void openDialogue(DialoguePayload payload) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        Entity e = mc.level.getEntity(payload.entityId());
        mc.setScreen(new DialogueScreen(e instanceof LivingEntity le ? le : null,
                NpcCharacter.byName(payload.character()), payload.lines()));
    }
}
