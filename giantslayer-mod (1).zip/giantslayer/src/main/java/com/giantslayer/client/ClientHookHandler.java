package com.giantslayer.client;

import com.giantslayer.GiantSlayer;
import com.giantslayer.entity.GiantEntity;
import com.giantslayer.item.ManeuverGearItem;
import com.giantslayer.network.HookStatePayload;
import com.giantslayer.network.HookSync;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.*;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;
import org.joml.Vector3f;

/**
 * Grapple physics run on the client (the client owns player movement in Minecraft),
 * the server is told the state so it can drain gas and cancel fall damage.
 */
@EventBusSubscriber(modid = GiantSlayer.MODID, value = Dist.CLIENT)
public class ClientHookHandler {
    private static final double RANGE = 45.0;
    private static final DustParticleOptions CABLE = new DustParticleOptions(new Vector3f(0.3f, 0.3f, 0.33f), 0.6f);

    private static boolean hooked, boosting, wasHookDown, sentHooked, sentBoost;
    private static Vec3 anchor = Vec3.ZERO;
    private static int anchorEntity = -1;
    private static Vec3 entityOffset = Vec3.ZERO;

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.level == null) {
            hooked = boosting = sentHooked = sentBoost = wasHookDown = false;
            return;
        }
        while (ModKeys.POWER.consumeClick()) PacketDistributor.sendToServer(new com.giantslayer.network.ActionPayload(com.giantslayer.network.ActionPayload.POWER));
        while (ModKeys.BROADSIDE.consumeClick()) PacketDistributor.sendToServer(new com.giantslayer.network.ActionPayload(com.giantslayer.network.ActionPayload.BROADSIDE));
        if (HookSync.forceRelease) {
            HookSync.forceRelease = false;
            release(player, true);
        }

        ItemStack gear = ManeuverGearItem.findGear(player);
        boolean hasGas = ManeuverGearItem.gas(gear) > 0 || (!gear.isEmpty() && player.getAbilities().instabuild);
        boolean canAct = hasGas && mc.screen == null && !player.isSpectator();

        boolean hookDown = ModKeys.HOOK.isDown();
        if (hookDown && !wasHookDown && canAct) fire(mc, player);
        if ((!hookDown || !hasGas) && hooked) release(player, true);
        wasHookDown = hookDown;

        if (hooked) pull(mc, player);

        boosting = canAct && ModKeys.BOOST.isDown() && !player.onGround();
        if (boosting) boost(mc, player);

        if (hooked != sentHooked || boosting != sentBoost) {
            sentHooked = hooked;
            sentBoost = boosting;
            PacketDistributor.sendToServer(new HookStatePayload(hooked, boosting));
        }
    }

    private static void fire(Minecraft mc, LocalPlayer player) {
        Vec3 start = player.getEyePosition();
        Vec3 look = player.getLookAngle();
        Vec3 end = start.add(look.scale(RANGE));

        BlockHitResult blockHit = mc.level.clip(new ClipContext(start, end,
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        Vec3 limit = blockHit.getType() == HitResult.Type.MISS ? end : blockHit.getLocation();

        AABB box = player.getBoundingBox().expandTowards(look.scale(RANGE)).inflate(1.0);
        EntityHitResult entityHit = ProjectileUtil.getEntityHitResult(player, start, limit, box,
                e -> e instanceof GiantEntity && e.isAlive(), start.distanceToSqr(limit));

        if (entityHit != null) {
            anchorEntity = entityHit.getEntity().getId();
            entityOffset = entityHit.getLocation().subtract(entityHit.getEntity().position());
            anchor = entityHit.getLocation();
        } else if (blockHit.getType() == HitResult.Type.BLOCK) {
            anchorEntity = -1;
            anchor = blockHit.getLocation();
        } else {
            player.playSound(SoundEvents.DISPENSER_FAIL, 0.5f, 1.6f);
            return;
        }
        hooked = true;
        player.playSound(SoundEvents.CROSSBOW_SHOOT, 0.8f, 1.5f);
    }

    private static void pull(Minecraft mc, LocalPlayer player) {
        if (anchorEntity != -1) {
            Entity e = mc.level.getEntity(anchorEntity);
            if (e == null || !e.isAlive()) { release(player, true); return; }
            anchor = e.position().add(entityOffset);
        }
        Vec3 center = player.position().add(0, player.getBbHeight() * 0.6, 0);
        Vec3 to = anchor.subtract(center);
        double dist = to.length();
        if (dist > RANGE + 10) { release(player, true); return; }

        Vec3 v = player.getDeltaMovement();
        if (dist > 1.5) {
            double strength = Math.min(0.30, 0.06 + dist * 0.012);
            v = v.scale(0.95).add(to.normalize().scale(strength));
        } else {
            v = v.scale(0.5); // hang at the anchor
        }
        if (v.length() > 2.0) v = v.normalize().scale(2.0);
        player.setDeltaMovement(v);
        player.resetFallDistance();

        int n = (int) Math.min(24, dist);
        for (int i = 1; i <= n; i++) {
            Vec3 p = center.add(to.scale(i / (double) (n + 1)));
            mc.level.addParticle(CABLE, p.x, p.y, p.z, 0, 0, 0);
        }
    }

    private static void boost(Minecraft mc, LocalPlayer player) {
        Vec3 look = player.getLookAngle();
        player.setDeltaMovement(player.getDeltaMovement().add(look.scale(0.11)).add(0, 0.03, 0));
        if (player.tickCount % 2 == 0) {
            mc.level.addParticle(ParticleTypes.CLOUD, player.getX() - look.x, player.getY() + 0.8, player.getZ() - look.z,
                    -look.x * 0.2, -look.y * 0.2, -look.z * 0.2);
        }
        if (player.tickCount % 6 == 0) player.playSound(SoundEvents.FIRE_EXTINGUISH, 0.25f, 1.8f);
    }

    private static void release(LocalPlayer player, boolean sound) {
        if (hooked && sound) player.playSound(SoundEvents.CHAIN_BREAK, 0.6f, 1.4f);
        hooked = false;
        anchorEntity = -1;
    }
}
