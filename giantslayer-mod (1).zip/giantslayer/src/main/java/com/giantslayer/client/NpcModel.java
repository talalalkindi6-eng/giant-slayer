package com.giantslayer.client;

import com.giantslayer.entity.StoryNpc;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.util.Mth;

/**
 * Humanoid model with personality:
 *  - Talking: gestures with the right hand, nods, other arm moves too.
 *  - Idle: Reyne stands with hands behind his back, Bram hammers, Mira rests a hand on her hip,
 *    Tova keeps glancing around the horizon.
 */
public class NpcModel extends HumanoidModel<StoryNpc> {
    public NpcModel(ModelPart root) { super(root); }

    @Override
    public void setupAnim(StoryNpc npc, float limbSwing, float limbSwingAmount, float age, float netHeadYaw, float headPitch) {
        super.setupAnim(npc, limbSwing, limbSwingAmount, age, netHeadYaw, headPitch);
        boolean moving = limbSwingAmount > 0.1f;

        if (npc.isTalking()) {
            rightArm.xRot = -0.9f + Mth.sin(age * 0.35f) * 0.35f;
            rightArm.zRot = -0.1f + Mth.cos(age * 0.2f) * 0.12f;
            leftArm.xRot = -0.3f + Mth.sin(age * 0.25f + 1.0f) * 0.15f;
            head.xRot += Mth.sin(age * 0.6f) * 0.06f;
        } else if (!moving) {
            switch (npc.getCharacter()) {
                case REYNE -> {
                    rightArm.xRot = 0.55f; rightArm.zRot = -0.3f;
                    leftArm.xRot = 0.55f;  leftArm.zRot = 0.3f;
                }
                case BRAM -> rightArm.xRot = -0.5f - Math.abs(Mth.sin(age * 0.15f)) * 1.1f;
                case MIRA -> { leftArm.zRot = -0.55f; leftArm.xRot = 0.1f; }
                case TOVA -> head.yRot += Mth.sin(age * 0.04f) * 0.6f;
                case SELA -> { // fruit-eater: hands slowly stir the water around her
                    rightArm.xRot = -0.7f + Mth.sin(age * 0.1f) * 0.25f;
                    leftArm.xRot = -0.7f + Mth.cos(age * 0.1f) * 0.25f;
                    rightArm.zRot = 0.35f + Mth.cos(age * 0.1f) * 0.1f;
                    leftArm.zRot = -0.35f - Mth.sin(age * 0.1f) * 0.1f;
                }
            }
        }
        hat.copyFrom(head);
    }
}
