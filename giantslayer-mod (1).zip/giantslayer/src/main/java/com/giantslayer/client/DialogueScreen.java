package com.giantslayer.client;

import com.giantslayer.story.NpcCharacter;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.entity.LivingEntity;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.glfw.GLFW;

import java.util.List;

/**
 * Story dialogue: live animated portrait of the speaker, typewriter text with a
 * per-character voice blip. Click / Space / Enter to advance.
 */
public class DialogueScreen extends Screen {
    private final @Nullable LivingEntity speaker;
    private final NpcCharacter character;
    private final List<Component> lines;
    private int index;
    private float shown;
    private int ticks;

    public DialogueScreen(@Nullable LivingEntity speaker, NpcCharacter character, List<String> keys) {
        super(Component.translatable("npc.giantslayer." + character.id));
        this.speaker = speaker;
        this.character = character;
        this.lines = keys.stream().map(k -> (Component) Component.translatable(k)).toList();
    }

    @Override public boolean isPauseScreen() { return false; }

    private String fullLine() { return lines.isEmpty() ? "" : lines.get(index).getString(); }

    @Override
    public void tick() {
        ticks++;
        String full = fullLine();
        if (shown < full.length()) {
            int before = (int) shown;
            shown = Math.min(full.length(), shown + 1.5f);
            if ((int) shown / 3 != before / 3 && minecraft != null) {
                float pitch = character.voicePitch + (minecraft.level != null ? minecraft.level.random.nextFloat() * 0.2f : 0f);
                minecraft.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.NOTE_BLOCK_HAT.value(), pitch, 0.35f));
            }
        }
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);

        int boxW = Math.min(380, width - 20);
        int boxH = 80;
        int x = (width - boxW) / 2;
        int y = height - boxH - 12;
        int portraitW = 74;

        // Frame + panel
        g.fill(x - 2, y - 2, x + boxW + 2, y + boxH + 2, 0xFFC8A060);
        g.fill(x, y, x + boxW, y + boxH, 0xF0161310);
        g.fill(x + portraitW, y + 6, x + portraitW + 1, y + boxH - 6, 0x80C8A060);

        // Live animated portrait (follows the mouse, plays the NPC's talking animation)
        if (speaker != null) {
            InventoryScreen.renderEntityInInventoryFollowsMouse(g, x + 4, y - 70, x + portraitW - 4, y + boxH - 4,
                    40, 0.0625f, mouseX, mouseY, speaker);
        }

        int tx = x + portraitW + 8;
        int textW = boxW - portraitW - 18;
        g.drawString(font, title, tx, y + 7, 0xFFD27F, true);
        g.drawString(font, (index + 1) + "/" + lines.size(), x + boxW - 26, y + 7, 0x908070, false);

        String visible = fullLine().substring(0, Math.min((int) shown, fullLine().length()));
        List<FormattedCharSequence> wrapped = font.split(Component.literal(visible), textW);
        for (int i = 0; i < wrapped.size() && i < 5; i++) {
            g.drawString(font, wrapped.get(i), tx, y + 22 + i * 10, 0xF0F0F0, false);
        }

        if (shown >= fullLine().length() && (ticks / 8) % 2 == 0) {
            g.drawString(font, "\u25B6", x + boxW - 12, y + boxH - 12, 0xFFD27F, false);
        }
    }

    private void advance() {
        if (shown < fullLine().length()) {
            shown = fullLine().length();
            return;
        }
        index++;
        shown = 0;
        if (index >= lines.size()) onClose();
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        advance();
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_SPACE || keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_E) {
            advance();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
