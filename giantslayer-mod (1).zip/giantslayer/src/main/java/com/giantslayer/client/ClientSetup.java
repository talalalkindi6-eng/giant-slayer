package com.giantslayer.client;

import com.giantslayer.GiantSlayer;
import com.giantslayer.registry.ModEntities;
import net.minecraft.client.renderer.entity.ThrownItemRenderer;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

@EventBusSubscriber(modid = GiantSlayer.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {
    @SubscribeEvent
    public static void registerLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(ShipModel.LAYER, ShipModel::createLayer);
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        // Model is 2 blocks tall at scale 1, so sy * 2 = the entity's base hitbox height.
        event.registerEntityRenderer(ModEntities.GIANT.get(),    ctx -> new GiantRenderer<>(ctx, "giant", 2.0f, 2.0f, 2.0f));
        event.registerEntityRenderer(ModEntities.SPRINTER.get(), ctx -> new GiantRenderer<>(ctx, "sprinter_giant", 1.5f, 2.4f, 1.5f));
        event.registerEntityRenderer(ModEntities.LEAPER.get(),   ctx -> new GiantRenderer<>(ctx, "leaper_giant", 2.0f, 1.9f, 2.0f));
        event.registerEntityRenderer(ModEntities.HOWLER.get(),   ctx -> new GiantRenderer<>(ctx, "howler_giant", 2.3f, 2.0f, 2.3f));
        event.registerEntityRenderer(ModEntities.BURROWER.get(), ctx -> new GiantRenderer<>(ctx, "burrower_giant", 2.4f, 1.8f, 2.4f));
        event.registerEntityRenderer(ModEntities.STORY_NPC.get(), StoryNpcRenderer::new);
        event.registerEntityRenderer(ModEntities.SHIP.get(), ShipRenderer::new);
        event.registerEntityRenderer(ModEntities.PIRATE.get(), PirateRenderer::new);
        event.registerEntityRenderer(ModEntities.PIRATE_CAPTAIN.get(), CaptainRenderer::new);
        event.registerEntityRenderer(ModEntities.THUNDER_LANCE.get(), ctx -> new ThrownItemRenderer<>(ctx, 1.2f, true));
        event.registerEntityRenderer(ModEntities.FLARE.get(), ctx -> new ThrownItemRenderer<>(ctx, 0.8f, true));
        event.registerEntityRenderer(ModEntities.CANNONBALL.get(), ctx -> new ThrownItemRenderer<>(ctx, 1.5f, false));
        event.registerEntityRenderer(ModEntities.BROOD.get(),    ctx -> new GiantRenderer<>(ctx, "brood_giant", 2.6f, 2.0f, 2.6f));
    }
}
