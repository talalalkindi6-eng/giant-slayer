package com.giantslayer.client;

import com.giantslayer.GiantSlayer;
import com.giantslayer.entity.PirateCaptainEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

public class CaptainRenderer extends HumanoidMobRenderer<PirateCaptainEntity, CaptainModel> {
    private static final ResourceLocation TEX = GiantSlayer.id("textures/entity/pirate_captain.png");

    public CaptainRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new CaptainModel(ctx.bakeLayer(ModelLayers.ZOMBIE)), 0.6f);
    }

    @Override
    protected void scale(PirateCaptainEntity e, PoseStack ps, float pt) { ps.scale(1.1f, 1.1f, 1.1f); }

    @Override
    public ResourceLocation getTextureLocation(PirateCaptainEntity e) { return TEX; }
}
