package com.giantslayer.client;

import com.giantslayer.GiantSlayer;
import com.giantslayer.entity.GiantEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

/**
 * Humanoid model stretched per giant type (lanky, stocky, hulking...).
 * The per-giant SCALE attribute is applied on top automatically.
 */
public class GiantRenderer<T extends GiantEntity> extends HumanoidMobRenderer<T, HumanoidModel<T>> {
    private final ResourceLocation texture;
    private final float sx, sy, sz;

    public GiantRenderer(EntityRendererProvider.Context ctx, String textureName, float sx, float sy, float sz) {
        super(ctx, new HumanoidModel<>(ctx.bakeLayer(ModelLayers.ZOMBIE)), 0.5f * sx);
        this.texture = GiantSlayer.id("textures/entity/" + textureName + ".png");
        this.sx = sx; this.sy = sy; this.sz = sz;
    }

    @Override
    protected void scale(T entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(sx, sy, sz);
    }

    @Override
    public ResourceLocation getTextureLocation(T entity) {
        return texture;
    }
}
