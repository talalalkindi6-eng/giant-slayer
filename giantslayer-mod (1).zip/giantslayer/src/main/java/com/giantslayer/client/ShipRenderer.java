package com.giantslayer.client;

import com.giantslayer.GiantSlayer;
import com.giantslayer.entity.ShipEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

public class ShipRenderer extends EntityRenderer<ShipEntity> {
    private static final ResourceLocation TEXTURE = GiantSlayer.id("textures/entity/ship.png");
    private final ShipModel model;

    public ShipRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.model = new ShipModel(ctx.bakeLayer(ShipModel.LAYER));
        this.shadowRadius = 1.5f;
    }

    @Override
    public void render(ShipEntity ship, float yaw, float partialTick, PoseStack ps, MultiBufferSource buffers, int light) {
        ps.pushPose();
        float age = ship.tickCount + partialTick;
        ps.mulPose(Axis.YP.rotationDegrees(180.0f - yaw));
        ps.mulPose(Axis.ZP.rotationDegrees(Mth.sin(age * 0.07f) * 2.0f)); // rocking on the waves
        ps.mulPose(Axis.XP.rotationDegrees(Mth.sin(age * 0.05f) * 1.0f));
        ps.scale(-1.0f, -1.0f, 1.0f);
        ps.translate(0.0, -1.3, 0.0);
        model.setupAnim(ship, 0, 0, age, 0, 0);
        model.renderToBuffer(ps, buffers.getBuffer(model.renderType(TEXTURE)), light, OverlayTexture.NO_OVERLAY, -1);
        ps.popPose();
        super.render(ship, yaw, partialTick, ps, buffers, light);
    }

    @Override
    public ResourceLocation getTextureLocation(ShipEntity ship) { return TEXTURE; }
}
