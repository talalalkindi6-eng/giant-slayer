package com.giantslayer.client;

import com.giantslayer.entity.PirateCaptainEntity;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.util.Mth;

/** While casting, the captain throws both arms skyward and sways as the wind gathers. */
public class CaptainModel extends HumanoidModel<PirateCaptainEntity> {
    public CaptainModel(ModelPart root) { super(root); }

    @Override
    public void setupAnim(PirateCaptainEntity e, float limbSwing, float limbSwingAmount, float age, float yaw, float pitch) {
        super.setupAnim(e, limbSwing, limbSwingAmount, age, yaw, pitch);
        if (e.isCasting()) {
            rightArm.xRot = -2.8f + Mth.sin(age * 0.5f) * 0.2f;
            leftArm.xRot = -2.8f + Mth.cos(age * 0.5f) * 0.2f;
            rightArm.zRot = 0.35f;
            leftArm.zRot = -0.35f;
            body.yRot = Mth.sin(age * 0.3f) * 0.15f;
            head.xRot = -0.4f;
            hat.copyFrom(head);
        }
    }
}
