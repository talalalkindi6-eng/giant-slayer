package com.giantslayer.client;

import com.giantslayer.GiantSlayer;
import com.giantslayer.entity.ShipEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.util.Mth;

/** Sloop: hull, bow, raised stern, mast, yard, billowing sail, flag and bowsprit. Bow points to -Z. */
public class ShipModel extends EntityModel<ShipEntity> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(GiantSlayer.id("ship"), "main");
    private final ModelPart root;
    private final ModelPart sail;
    private final ModelPart flag;

    public ShipModel(ModelPart root) {
        this.root = root;
        this.sail = root.getChild("sail");
        this.flag = root.getChild("flag");
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition p = mesh.getRoot();
        p.addOrReplaceChild("bottom", CubeListBuilder.create().texOffs(0, 0).addBox(-12, 20, -32, 24, 4, 64), PartPose.ZERO);
        p.addOrReplaceChild("left", CubeListBuilder.create().texOffs(0, 70).addBox(-12, 12, -32, 2, 8, 64), PartPose.ZERO);
        p.addOrReplaceChild("right", CubeListBuilder.create().texOffs(0, 144).addBox(10, 12, -32, 2, 8, 64), PartPose.ZERO);
        p.addOrReplaceChild("bow", CubeListBuilder.create().texOffs(140, 70).addBox(-10, 12, -34, 20, 8, 2), PartPose.ZERO);
        p.addOrReplaceChild("stern", CubeListBuilder.create().texOffs(140, 82).addBox(-10, 8, 30, 20, 12, 2), PartPose.ZERO);
        p.addOrReplaceChild("mast", CubeListBuilder.create().texOffs(200, 0).addBox(-1.5f, -60, -4, 3, 72, 3), PartPose.ZERO);
        p.addOrReplaceChild("yard", CubeListBuilder.create().texOffs(140, 100).addBox(-20, -52, -6, 40, 2, 2), PartPose.ZERO);
        p.addOrReplaceChild("sail", CubeListBuilder.create().texOffs(140, 110).addBox(-18, 0, 0, 36, 40, 1),
                PartPose.offset(0, -50, -6));
        p.addOrReplaceChild("bowsprit", CubeListBuilder.create().texOffs(140, 160).addBox(-1, 10, -46, 2, 2, 14), PartPose.ZERO);
        p.addOrReplaceChild("flag", CubeListBuilder.create().texOffs(220, 80).addBox(0, 0, 0, 10, 6, 1),
                PartPose.offset(1.5f, -60, -3));
        return LayerDefinition.create(mesh, 256, 256);
    }

    @Override
    public void setupAnim(ShipEntity ship, float limbSwing, float limbSwingAmount, float age, float yaw, float pitch) {
        double speed = ship.getDeltaMovement().horizontalDistance();
        sail.xRot = (float) (-Math.min(0.35, speed * 0.6)) + Mth.sin(age * 0.08f) * 0.03f; // billows with speed
        flag.yRot = Mth.sin(age * 0.3f) * 0.35f;                                          // flutters
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int light, int overlay, int color) {
        root.render(poseStack, buffer, light, overlay, color);
    }
}
