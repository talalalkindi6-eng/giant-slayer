package com.giantslayer.client;

import com.giantslayer.GiantSlayer;
import com.giantslayer.entity.StoryNpc;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

public class StoryNpcRenderer extends HumanoidMobRenderer<StoryNpc, NpcModel> {
    public StoryNpcRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new NpcModel(ctx.bakeLayer(ModelLayers.ZOMBIE)), 0.5f);
    }

    @Override
    public ResourceLocation getTextureLocation(StoryNpc npc) {
        return GiantSlayer.id("textures/entity/npc/" + npc.getCharacter().id + ".png");
    }
}
