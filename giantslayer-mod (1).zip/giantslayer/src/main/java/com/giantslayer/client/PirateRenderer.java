package com.giantslayer.client;

import com.giantslayer.GiantSlayer;
import com.giantslayer.entity.PirateEntity;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

public class PirateRenderer extends HumanoidMobRenderer<PirateEntity, HumanoidModel<PirateEntity>> {
    private static final ResourceLocation[] TEX = {
            GiantSlayer.id("textures/entity/pirate_0.png"), GiantSlayer.id("textures/entity/pirate_1.png")};

    public PirateRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new HumanoidModel<>(ctx.bakeLayer(ModelLayers.ZOMBIE)), 0.5f);
    }

    @Override
    public ResourceLocation getTextureLocation(PirateEntity e) { return TEX[Math.floorMod(e.getVariant(), TEX.length)]; }
}
