package com.giantslayer.entity;

import com.giantslayer.story.NpcCharacter;
import com.giantslayer.story.StoryManager;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

/** A story character. Can't be hurt, stays near camp, faces you and gestures while talking. */
public class StoryNpc extends PathfinderMob {
    private static final EntityDataAccessor<Integer> CHARACTER =
            SynchedEntityData.defineId(StoryNpc.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> TALKING =
            SynchedEntityData.defineId(StoryNpc.class, EntityDataSerializers.BOOLEAN);

    @Nullable private Player talkingTo;
    private int talkTicks;
    @Nullable private BlockPos home;

    public StoryNpc(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes().add(Attributes.MAX_HEALTH, 20.0).add(Attributes.MOVEMENT_SPEED, 0.25);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(CHARACTER, 0);
        builder.define(TALKING, false);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new LookAtPlayerGoal(this, Player.class, 6.0f, 1.0f));
        goalSelector.addGoal(4, new MoveTowardsRestrictionGoal(this, 0.6));
        goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.45));
        goalSelector.addGoal(6, new RandomLookAroundGoal(this));
    }

    public NpcCharacter getCharacter() { return NpcCharacter.byIndex(entityData.get(CHARACTER)); }
    public boolean isTalking() { return entityData.get(TALKING); }

    public void setCharacter(NpcCharacter c) {
        entityData.set(CHARACTER, c.ordinal());
        setCustomName(Component.translatable("npc.giantslayer." + c.id));
        setCustomNameVisible(true);
        setItemSlot(EquipmentSlot.MAINHAND, c.heldItem());
        setDropChance(EquipmentSlot.MAINHAND, 0.0f);
    }

    public void setHome(BlockPos pos) {
        home = pos;
        restrictTo(pos, 8);
    }

    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
        if (!level().isClientSide && player instanceof ServerPlayer sp) {
            talkingTo = player;
            talkTicks = 100;
            entityData.set(TALKING, true);
            getNavigation().stop();
            StoryManager.talk(sp, this);
        }
        return InteractionResult.sidedSuccess(level().isClientSide);
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        if (talkTicks > 0) {
            talkTicks--;
            getNavigation().stop();
            if (talkingTo != null) getLookControl().setLookAt(talkingTo, 30.0f, 30.0f);
            if (talkTicks == 0) {
                entityData.set(TALKING, false);
                talkingTo = null;
            }
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide && getCharacter() == NpcCharacter.SELA && random.nextInt(3) == 0) {
            level().addParticle(net.minecraft.core.particles.ParticleTypes.DRIPPING_WATER,
                    getX() + (random.nextDouble() - 0.5) * 1.0, getY() + 0.9 + random.nextDouble() * 0.6,
                    getZ() + (random.nextDouble() - 0.5) * 1.0, 0, 0, 0);
        }
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        return source.is(DamageTypeTags.BYPASSES_INVULNERABILITY) && super.hurt(source, amount);
    }

    @Override public boolean removeWhenFarAway(double dist) { return false; }
    @Override public boolean isPushable() { return false; }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Character", entityData.get(CHARACTER));
        if (home != null) tag.putLong("Home", home.asLong());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        entityData.set(CHARACTER, tag.getInt("Character"));
        if (tag.contains("Home")) setHome(BlockPos.of(tag.getLong("Home")));
    }
}
