package com.giantslayer.entity;

import com.giantslayer.registry.ModEntities;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;

/**
 * Huge and slow. Every time it loses a quarter of its health, two smaller giants
 * split off it in a burst of steam. A clean nape kill avoids the whole brood.
 */
public class BroodGiant extends GiantEntity {
    private int broodStage;

    public BroodGiant(EntityType<? extends Monster> type, Level level) { super(type, level); }

    public static AttributeSupplier.Builder createAttributes() {
        return GiantEntity.createAttributes().add(Attributes.MOVEMENT_SPEED, 0.17);
    }

    @Override protected double minScale() { return 3.0; }
    @Override protected double maxScale() { return 4.0; }
    @Override protected double healthPerScale() { return 90.0; }
    @Override protected double damagePerScale() { return 6.0; }
    @Override public float getVoicePitch() { return 0.3f; }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean result = super.hurt(source, amount);
        if (result && isAlive() && level() instanceof ServerLevel sl) {
            float frac = getHealth() / getMaxHealth();
            int stage = frac < 0.25f ? 3 : frac < 0.5f ? 2 : frac < 0.75f ? 1 : 0;
            while (broodStage < stage) {
                broodStage++;
                spawnBrood(sl);
            }
        }
        return result;
    }

    private void spawnBrood(ServerLevel sl) {
        playSound(SoundEvents.SLIME_SQUISH, 3.0f, 0.4f);
        sl.sendParticles(ParticleTypes.CLOUD, getX(), getY() + getBbHeight() * 0.5, getZ(), 60,
                getBbWidth(), getBbHeight() * 0.3, getBbWidth(), 0.05);
        for (int i = 0; i < 2; i++) {
            GiantEntity child = ModEntities.GIANT.get().create(sl);
            if (child == null) continue;
            double ox = (random.nextDouble() - 0.5) * 6, oz = (random.nextDouble() - 0.5) * 6;
            child.moveTo(getX() + ox, getY(), getZ() + oz, random.nextFloat() * 360f, 0f);
            child.finalizeSpawn(sl, sl.getCurrentDifficultyAt(child.blockPosition()), MobSpawnType.MOB_SUMMONED, null);
            child.setGiantScale(1.2 + random.nextDouble() * 0.4);
            child.setTarget(getTarget());
            sl.addFreshEntity(child);
        }
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("BroodStage", broodStage);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        broodStage = tag.getInt("BroodStage");
    }
}
