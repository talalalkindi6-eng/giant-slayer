package com.giantslayer.entity;

import com.giantslayer.item.SlayerBladeItem;
import com.giantslayer.world.WallZones;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import com.giantslayer.network.OutOfGasPayload;
import net.neoforged.neoforge.network.PacketDistributor;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Difficulty;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

/**
 * A colossal humanoid. Wounds anywhere except the back of the neck barely matter and
 * regenerate in clouds of steam. A blade strike to the nape kills it outright.
 */
public class GiantEntity extends Monster {
    /** Set when a blade nape cut lands, so the story can credit "nape kills". */
    public boolean napeCut;
    private int distractedTicks;

    /** Flares: forget all targets for a while. */
    public void distract(int ticks) {
        distractedTicks = Math.max(distractedTicks, ticks);
        setTarget(null);
    }

    public GiantEntity(EntityType<? extends Monster> type, Level level) {
        super(type, level);
        this.xpReward = 50;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 120.0)
                .add(Attributes.MOVEMENT_SPEED, 0.24)
                .add(Attributes.ATTACK_DAMAGE, 10.0)
                .add(Attributes.ATTACK_KNOCKBACK, 1.5)
                .add(Attributes.FOLLOW_RANGE, 48.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0)
                .add(Attributes.STEP_HEIGHT, 1.5);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.0, true));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 24.0f));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));

        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, AbstractVillager.class, false));
        this.targetSelector.addGoal(4, new NearestAttackableTargetGoal<>(this, IronGolem.class, false));
    }

    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty,
                                        MobSpawnType spawnType, @Nullable SpawnGroupData data) {
        // Random size: roughly 6 to 16 blocks tall.
        setGiantScale(minScale() + level.getRandom().nextDouble() * (maxScale() - minScale()));
        return super.finalizeSpawn(level, difficulty, spawnType, data);
    }

    public void setGiantScale(double scale) {
        getAttribute(Attributes.SCALE).setBaseValue(scale);
        getAttribute(Attributes.MAX_HEALTH).setBaseValue(healthPerScale() * scale);
        getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(damagePerScale() * scale);
        setHealth(getMaxHealth());
    }

    // Per-type tuning, overridden by the special giant types.
    protected double minScale() { return 1.5; }
    protected double maxScale() { return 4.0; }
    protected double healthPerScale() { return 60.0; }
    protected double damagePerScale() { return 5.0; }

    /** Damages, flings and knocks grapples loose from everything nearby (giants excluded). */
    protected void shockwave(double radius, float damage, double lift) {
        if (!(level() instanceof ServerLevel sl)) return;
        for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(radius),
                e -> e != this && !(e instanceof GiantEntity))) {
            if (e instanceof Player pl && (pl.isCreative() || pl.isSpectator())) continue;
            e.hurt(damageSources().mobAttack(this), damage);
            Vec3 push = new Vec3(e.getX() - getX(), 0, e.getZ() - getZ()).normalize().scale(1.2).add(0, lift, 0);
            e.setDeltaMovement(push);
            e.hurtMarked = true;
            if (e instanceof ServerPlayer sp) PacketDistributor.sendToPlayer(sp, new OutOfGasPayload());
        }
    }

    /** True if the player is behind the giant and up near its neck. */
    public boolean isNapeHit(Player player) {
        double neckY = getY() + getBbHeight() * 0.85;
        double eyeY = player.getEyeY();
        boolean high = eyeY > neckY - 2.0 && eyeY < getY() + getBbHeight() + 3.0;
        if (!high) return false;

        Vec3 toPlayer = new Vec3(player.getX() - getX(), 0, player.getZ() - getZ());
        if (toPlayer.lengthSqr() < 0.25) return true; // standing right on its shoulders
        Vec3 facing = Vec3.directionFromRotation(0, this.yBodyRot);
        return toPlayer.normalize().dot(facing) < -0.1;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return super.hurt(source, amount);
        if (source.is(DamageTypeTags.IS_FALL)) return false;

        if (source.getEntity() instanceof Player player && source.getDirectEntity() == player) {
            if (isNapeHit(player)) {
                ItemStack weapon = player.getMainHandItem();
                boolean blade = weapon.getItem() instanceof SlayerBladeItem;
                if (!level().isClientSide) {
                    ServerLevel sl = (ServerLevel) level();
                    sl.sendParticles(ParticleTypes.CRIT, getX(), getY() + getBbHeight() * 0.88, getZ(),
                            30, 0.5, 0.3, 0.5, 0.4);
                    sl.playSound(null, blockPosition(), SoundEvents.PLAYER_ATTACK_CRIT, SoundSource.PLAYERS, 2.0f, 0.6f);
                    player.displayClientMessage(Component.translatable("message.giantslayer.nape_cut"), true);
                    if (blade) weapon.hurtAndBreak(8, player, EquipmentSlot.MAINHAND); // blades dull fast
                }
                if (blade) napeCut = true;
                float dmg = blade ? getMaxHealth() * 10.0f : amount * 4.0f;
                return super.hurt(source, dmg);
            }
            // Flesh wounds: barely scratch it.
            return super.hurt(source, amount * 0.15f);
        }
        // Arrows, explosions, lava etc. are heavily resisted.
        return super.hurt(source, amount * 0.25f);
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (!level().isClientSide && distractedTicks > 0) {
            distractedTicks--;
            if (getTarget() != null) setTarget(null);
        }
        if (!level().isClientSide && isAlive() && tickCount % 20 == 0 && getHealth() < getMaxHealth()) {
            heal(getMaxHealth() * 0.02f);
            ((ServerLevel) level()).sendParticles(ParticleTypes.CLOUD,
                    getX(), getY() + getBbHeight() * 0.6, getZ(), 4,
                    getBbWidth() * 0.4, getBbHeight() * 0.3, getBbWidth() * 0.4, 0.02);
        }
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.CLOUD, getX(), getY() + getBbHeight() * 0.5, getZ(),
                    120, getBbWidth(), getBbHeight() * 0.5, getBbWidth(), 0.08);
        }
    }

    // --- Spawning ---------------------------------------------------------

    public static <T extends GiantEntity> boolean checkGiantSpawnRules(EntityType<T> type, ServerLevelAccessor level,
                                               MobSpawnType reason, BlockPos pos, RandomSource random) {
        if (level.getDifficulty() == Difficulty.PEACEFUL) return false;
        if (reason == MobSpawnType.NATURAL || reason == MobSpawnType.CHUNK_GENERATION) {
            if (random.nextInt(30) != 0) return false;                 // keep them rare
            if (!level.canSeeSky(pos)) return false;                    // surface only
            if (WallZones.get(level.getLevel()).isProtected(pos)) return false; // never inside your walls
            if (level.getEntitiesOfClass(GiantEntity.class, new AABB(pos).inflate(96)).size() >= 3) return false;
        }
        return Mob.checkMobSpawnRules(type, level, reason, pos, random);
    }

    // --- Sounds -----------------------------------------------------------

    @Override protected SoundEvent getAmbientSound() { return SoundEvents.ZOMBIE_AMBIENT; }
    @Override protected SoundEvent getHurtSound(DamageSource source) { return SoundEvents.ZOMBIE_HURT; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.ZOMBIE_DEATH; }
    @Override public float getVoicePitch() { return 0.4f; }
    @Override protected float getSoundVolume() { return 2.5f; }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        this.playSound(SoundEvents.RAVAGER_STEP, 1.2f, 0.6f);
    }
}
