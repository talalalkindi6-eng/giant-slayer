package com.giantslayer.entity;

import com.giantslayer.network.OutOfGasPayload;
import com.giantslayer.registry.ModEntities;
import com.giantslayer.registry.ModItems;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.BossEvent;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;
import org.jetbrains.annotations.Nullable;

/**
 * Captain Morrow Vane, the Storm Corsair. A Galefruit eater.
 * Raises his arms to cast (animated): Gale Blast, Wind Step (teleports behind you),
 * and calls his crew when hurt. Boss bar.
 */
public class PirateCaptainEntity extends Monster {
    private static final EntityDataAccessor<Boolean> CASTING =
            SynchedEntityData.defineId(PirateCaptainEntity.class, EntityDataSerializers.BOOLEAN);

    private final ServerBossEvent bossEvent = new ServerBossEvent(
            net.minecraft.network.chat.Component.translatable("entity.giantslayer.pirate_captain"),
            BossEvent.BossBarColor.BLUE, BossEvent.BossBarOverlay.NOTCHED_10);
    private int castTicks;
    private int abilityCooldown = 60;
    private int summonCooldown = 100;
    private int pendingCast; // 1 = gale, 2 = step, 3 = summon

    public PirateCaptainEntity(EntityType<? extends Monster> type, Level level) {
        super(type, level);
        this.xpReward = 120;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 300.0).add(Attributes.MOVEMENT_SPEED, 0.3)
                .add(Attributes.ATTACK_DAMAGE, 10.0).add(Attributes.ARMOR, 8.0)
                .add(Attributes.FOLLOW_RANGE, 40.0).add(Attributes.KNOCKBACK_RESISTANCE, 0.6);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(CASTING, false);
    }

    public boolean isCasting() { return entityData.get(CASTING); }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.2, true));
        goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8));
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 16.0f));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty,
                                        MobSpawnType type, @Nullable SpawnGroupData data) {
        setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(ModItems.CUTLASS.get()));
        setDropChance(EquipmentSlot.MAINHAND, 1.0f);
        setPersistenceRequired();
        return super.finalizeSpawn(level, difficulty, type, data);
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide && isCasting()) {
            for (int i = 0; i < 3; i++) {
                double a = (tickCount + i * 2.1) * 0.4;
                level().addParticle(ParticleTypes.CLOUD, getX() + Math.cos(a) * 1.2, getY() + 0.3 + i * 0.6,
                        getZ() + Math.sin(a) * 1.2, 0, 0.05, 0);
            }
        }
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        bossEvent.setProgress(getHealth() / getMaxHealth());
        if (abilityCooldown > 0) abilityCooldown--;
        if (summonCooldown > 0) summonCooldown--;

        if (castTicks > 0) {
            castTicks--;
            getNavigation().stop();
            if (castTicks == 0) {
                entityData.set(CASTING, false);
                release();
            }
            return;
        }
        LivingEntity t = getTarget();
        if (t == null || !t.isAlive()) return;
        if (summonCooldown <= 0 && getHealth() < getMaxHealth() * 0.6f) { startCast(3, 25); summonCooldown = 400; return; }
        if (abilityCooldown <= 0) {
            double d = distanceTo(t);
            if (d < 10) startCast(1, 20);
            else if (d < 30) startCast(2, 12);
            abilityCooldown = 80 + random.nextInt(40);
        }
    }

    private void startCast(int which, int ticks) {
        pendingCast = which;
        castTicks = ticks;
        entityData.set(CASTING, true);
        playSound(SoundEvents.EVOKER_PREPARE_ATTACK, 2.0f, 0.8f);
    }

    private void release() {
        if (!(level() instanceof ServerLevel sl)) return;
        LivingEntity t = getTarget();
        switch (pendingCast) {
            case 1 -> { // Gale Blast
                for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(10),
                        e -> e != this && !(e instanceof PirateEntity))) {
                    Vec3 dir = new Vec3(e.getX() - getX(), 0, e.getZ() - getZ()).normalize();
                    e.hurt(damageSources().mobAttack(this), 6.0f);
                    e.setDeltaMovement(dir.scale(2.0).add(0, 0.6, 0));
                    e.hurtMarked = true;
                    if (e instanceof ServerPlayer sp) PacketDistributor.sendToPlayer(sp, new OutOfGasPayload());
                }
                sl.sendParticles(ParticleTypes.CLOUD, getX(), getY() + 1, getZ(), 80, 3, 1, 3, 0.3);
                playSound(SoundEvents.ENDER_DRAGON_FLAP, 3.0f, 0.7f);
            }
            case 2 -> { // Wind Step: appear behind the target
                if (t != null) {
                    Vec3 back = t.getLookAngle().multiply(1, 0, 1).normalize().scale(-2.5);
                    sl.sendParticles(ParticleTypes.CLOUD, getX(), getY() + 1, getZ(), 30, 0.4, 0.8, 0.4, 0.05);
                    teleportTo(t.getX() + back.x, t.getY(), t.getZ() + back.z);
                    sl.sendParticles(ParticleTypes.CLOUD, getX(), getY() + 1, getZ(), 30, 0.4, 0.8, 0.4, 0.05);
                    playSound(SoundEvents.ENDERMAN_TELEPORT, 1.5f, 0.6f);
                }
            }
            case 3 -> { // All hands!
                for (int i = 0; i < 3; i++) {
                    PirateEntity p = ModEntities.PIRATE.get().create(sl);
                    if (p == null) continue;
                    p.moveTo(getX() + random.nextInt(7) - 3, getY(), getZ() + random.nextInt(7) - 3, random.nextFloat() * 360, 0);
                    p.finalizeSpawn(sl, sl.getCurrentDifficultyAt(p.blockPosition()), MobSpawnType.MOB_SUMMONED, null);
                    p.setTarget(t);
                    sl.addFreshEntity(p);
                }
                playSound(SoundEvents.RAID_HORN.value(), 3.0f, 1.2f);
            }
        }
        pendingCast = 0;
    }

    @Override public void startSeenByPlayer(ServerPlayer player) { super.startSeenByPlayer(player); bossEvent.addPlayer(player); }
    @Override public void stopSeenByPlayer(ServerPlayer player) { super.stopSeenByPlayer(player); bossEvent.removePlayer(player); }
    @Override public boolean removeWhenFarAway(double d) { return false; }

    @Override protected SoundEvent getAmbientSound() { return SoundEvents.VINDICATOR_AMBIENT; }
    @Override protected SoundEvent getHurtSound(DamageSource s) { return SoundEvents.VINDICATOR_HURT; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.VINDICATOR_DEATH; }
}
