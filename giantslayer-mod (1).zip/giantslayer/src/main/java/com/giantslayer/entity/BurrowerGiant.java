package com.giantslayer.entity;

import com.giantslayer.world.WallZones;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;

/**
 * Sinks into the earth, tunnels, and bursts up right under its prey, flinging everything skyward.
 * It can't tunnel past your walls.
 */
public class BurrowerGiant extends GiantEntity {
    private int burrowTicks;
    private int burrowCooldown = 100;

    public BurrowerGiant(EntityType<? extends Monster> type, Level level) { super(type, level); }

    public static AttributeSupplier.Builder createAttributes() { return GiantEntity.createAttributes(); }

    @Override protected double minScale() { return 1.8; }
    @Override protected double maxScale() { return 3.2; }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (burrowTicks > 0 && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return false;
        return super.hurt(source, amount);
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (!(level() instanceof ServerLevel sl)) return;
        if (burrowCooldown > 0) burrowCooldown--;

        if (burrowTicks > 0) {
            burrowTicks--;
            getNavigation().stop();
            setDeltaMovement(0, getDeltaMovement().y, 0);
            sl.sendParticles(groundParticle(), getX(), getY() + 0.2, getZ(), 6, getBbWidth(), 0.1, getBbWidth(), 0.1);
            if (burrowTicks == 0) emerge(sl);
            return;
        }
        LivingEntity t = getTarget();
        if (t != null && t.isAlive() && onGround() && burrowCooldown <= 0) {
            double d = distanceTo(t);
            if (d > 6 && d < 40 && random.nextInt(20) == 0 && !WallZones.get(sl).isProtected(t.blockPosition())) {
                burrowTicks = 40;
                setInvisible(true);
                playSound(SoundEvents.WARDEN_DIG, 3.0f, 0.6f);
            }
        }
    }

    private void emerge(ServerLevel sl) {
        setInvisible(false);
        burrowCooldown = 200;
        LivingEntity t = getTarget();
        if (t != null && t.isAlive() && !WallZones.get(sl).isProtected(t.blockPosition())) {
            int y = sl.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, t.getBlockX(), t.getBlockZ());
            teleportTo(t.getX(), y, t.getZ());
        }
        playSound(SoundEvents.WARDEN_EMERGE, 3.0f, 0.7f);
        sl.sendParticles(groundParticle(), getX(), getY() + 0.5, getZ(), 80, getBbWidth() * 1.5, 1.0, getBbWidth() * 1.5, 0.3);
        float s = getScale();
        shockwave(2.0 * s, 3.0f * s, 1.1);
    }

    private BlockParticleOption groundParticle() {
        BlockState below = level().getBlockState(blockPosition().below());
        if (below.isAir()) below = Blocks.DIRT.defaultBlockState();
        return new BlockParticleOption(ParticleTypes.BLOCK, below);
    }
}
