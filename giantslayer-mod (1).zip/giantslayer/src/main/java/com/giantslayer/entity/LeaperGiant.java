package com.giantslayer.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Hurls itself through the air at distant prey and lands with a ground-shaking slam. */
public class LeaperGiant extends GiantEntity {
    private int leapCooldown = 60;
    private boolean leaping;
    private int leapTicks;

    public LeaperGiant(EntityType<? extends Monster> type, Level level) { super(type, level); }

    public static AttributeSupplier.Builder createAttributes() { return GiantEntity.createAttributes(); }

    @Override protected double minScale() { return 1.6; }
    @Override protected double maxScale() { return 3.0; }
    @Override protected double healthPerScale() { return 50.0; }

    @Override
    public void aiStep() {
        super.aiStep();
        if (level().isClientSide) return;
        if (leapCooldown > 0) leapCooldown--;

        if (leaping) {
            leapTicks++;
            if (leapTicks > 5 && onGround()) { leaping = false; land(); }
            return;
        }
        LivingEntity t = getTarget();
        if (t != null && t.isAlive() && onGround() && leapCooldown <= 0) {
            double d = distanceTo(t);
            if (d > 8 && d < 30 && random.nextInt(15) == 0) leapAt(t, d);
        }
    }

    private void leapAt(LivingEntity t, double d) {
        Vec3 dir = new Vec3(t.getX() - getX(), 0, t.getZ() - getZ()).normalize();
        double h = Math.min(3.0, d * 0.1);
        getNavigation().stop();
        setDeltaMovement(dir.x * h, 0.9 + d * 0.015, dir.z * h);
        hasImpulse = true;
        leaping = true;
        leapTicks = 0;
        leapCooldown = 120;
        playSound(SoundEvents.RAVAGER_ATTACK, 2.0f, 0.5f);
    }

    private void land() {
        float s = getScale();
        shockwave(2.5 * s, 3.0f * s, 0.6);
        playSound(SoundEvents.ANVIL_LAND, 2.0f, 0.4f);
        if (level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.EXPLOSION, getX(), getY() + 0.5, getZ(), 6, s, 0.3, s, 0.0);
        }
    }
}
