package com.giantslayer.entity.projectile;

import com.giantslayer.entity.GiantEntity;
import com.giantslayer.registry.ModEntities;
import com.giantslayer.registry.ModItems;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Sticks into whatever it hits and detonates after 1.5s.
 * Stuck in a giant: takes ~60% of its health. Stuck in the nape (high on its back): instant kill.
 * The blast doesn't break blocks.
 */
public class ThunderLanceEntity extends ThrowableItemProjectile {
    private int fuse = -1;
    private int stuckTo = -1;
    private Vec3 offset = Vec3.ZERO;
    private boolean napeStick;

    public ThunderLanceEntity(EntityType<? extends ThunderLanceEntity> type, Level level) { super(type, level); }

    public ThunderLanceEntity(Level level, LivingEntity shooter) {
        super(ModEntities.THUNDER_LANCE.get(), shooter, level);
    }

    @Override protected Item getDefaultItem() { return ModItems.THUNDER_LANCE.get(); }
    @Override protected double getDefaultGravity() { return 0.02; }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        if (level().isClientSide || fuse >= 0) return;
        Entity e = result.getEntity();
        stuckTo = e.getId();
        offset = position().subtract(e.position());
        if (e instanceof GiantEntity g) {
            Vec3 facing = Vec3.directionFromRotation(0, g.yBodyRot);
            Vec3 flat = new Vec3(offset.x, 0, offset.z);
            boolean behind = flat.lengthSqr() < 0.01 || flat.normalize().dot(facing) < 0.1;
            napeStick = behind && offset.y > g.getBbHeight() * 0.75;
        }
        arm();
    }

    @Override
    protected void onHitBlock(BlockHitResult result) {
        super.onHitBlock(result);
        if (!level().isClientSide && fuse < 0) arm();
    }

    private void arm() {
        fuse = 30;
        setDeltaMovement(Vec3.ZERO);
        setNoGravity(true);
        playSound(SoundEvents.TNT_PRIMED, 1.0f, 1.4f);
    }

    @Override
    public void tick() {
        if (fuse >= 0) {
            if (level() instanceof ServerLevel sl) {
                if (stuckTo != -1) {
                    Entity e = sl.getEntity(stuckTo);
                    if (e != null && e.isAlive()) setPos(e.position().add(offset));
                }
                sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, getX(), getY(), getZ(), 3, 0.1, 0.1, 0.1, 0.05);
                if (--fuse <= 0) detonate(sl);
            }
            return;
        }
        super.tick();
    }

    private void detonate(ServerLevel sl) {
        Entity owner = getOwner();
        if (stuckTo != -1 && sl.getEntity(stuckTo) instanceof GiantEntity g && g.isAlive()) {
            // Giants take 25% from indirect damage, so these become 60% / guaranteed kill.
            if (napeStick) g.napeCut = true;
            float dmg = napeStick ? g.getMaxHealth() * 40.0f : g.getMaxHealth() * 2.4f;
            g.hurt(damageSources().explosion(this, owner), dmg);
        }
        sl.explode(this, getX(), getY(), getZ(), 2.5f, Level.ExplosionInteraction.NONE);
        discard();
    }
}
