package com.giantslayer.entity;

import com.giantslayer.network.OutOfGasPayload;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Its roar blasts players back, snaps their grapple lines, slows and dizzies them,
 * and calls every giant within 64 blocks to the hunt. Kill it first.
 */
public class HowlerGiant extends GiantEntity {
    private int roarCooldown = 100;
    private int roarFreeze;

    public HowlerGiant(EntityType<? extends Monster> type, Level level) { super(type, level); }

    public static AttributeSupplier.Builder createAttributes() { return GiantEntity.createAttributes(); }

    @Override protected double minScale() { return 2.0; }
    @Override protected double maxScale() { return 3.5; }

    @Override
    public void aiStep() {
        super.aiStep();
        if (!(level() instanceof ServerLevel sl)) return;
        if (roarFreeze > 0) { roarFreeze--; getNavigation().stop(); }
        if (roarCooldown > 0) roarCooldown--;

        LivingEntity t = getTarget();
        if (t != null && t.isAlive() && roarCooldown <= 0 && distanceTo(t) < 28 && random.nextInt(10) == 0) {
            roar(sl, t);
        }
    }

    private void roar(ServerLevel sl, LivingEntity target) {
        roarCooldown = 220;
        roarFreeze = 30;
        playSound(SoundEvents.RAVAGER_ROAR, 4.0f, 0.5f);
        sl.sendParticles(ParticleTypes.SONIC_BOOM, getX(), getEyeY(), getZ(), 1, 0, 0, 0, 0);

        for (Player p : sl.getEntitiesOfClass(Player.class, getBoundingBox().inflate(20))) {
            if (p.isCreative() || p.isSpectator()) continue;
            Vec3 push = new Vec3(p.getX() - getX(), 0, p.getZ() - getZ()).normalize().scale(1.6).add(0, 0.4, 0);
            p.setDeltaMovement(push);
            p.hurtMarked = true;
            p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 1));
            p.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 80, 0));
            if (p instanceof ServerPlayer sp) PacketDistributor.sendToPlayer(sp, new OutOfGasPayload());
        }
        for (GiantEntity g : sl.getEntitiesOfClass(GiantEntity.class, getBoundingBox().inflate(64), g -> g != this)) {
            g.setTarget(target);
        }
    }
}
