package com.giantslayer.entity.projectile;

import com.giantslayer.entity.GiantEntity;
import com.giantslayer.registry.ModEntities;
import com.giantslayer.registry.ModItems;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

/** Wall cannon shot: 40% of a giant's health and staggers it (heavy slowness). */
public class CannonballEntity extends ThrowableItemProjectile {
    public CannonballEntity(EntityType<? extends CannonballEntity> type, Level level) { super(type, level); }

    public CannonballEntity(Level level, double x, double y, double z) {
        super(ModEntities.CANNONBALL.get(), x, y, z, level);
    }

    @Override protected Item getDefaultItem() { return ModItems.CANNONBALL.get(); }
    @Override protected double getDefaultGravity() { return 0.04; }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        if (level().isClientSide) return;
        Entity e = result.getEntity();
        if (e instanceof GiantEntity g) {
            g.hurt(damageSources().thrown(this, getOwner()), g.getMaxHealth() * 1.6f);
            g.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 3));
        } else {
            e.hurt(damageSources().thrown(this, getOwner()), 12.0f);
        }
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (!level().isClientSide && !isRemoved()) {
            level().explode(this, getX(), getY(), getZ(), 1.5f, Level.ExplosionInteraction.NONE);
            discard();
        }
    }
}
