package com.giantslayer.entity.projectile;

import com.giantslayer.entity.GiantEntity;
import com.giantslayer.item.FlareColor;
import com.giantslayer.registry.ModEntities;
import com.giantslayer.registry.ModItems;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.HitResult;
import org.joml.Vector3f;

import java.util.List;

/** A signal flare. Arcs up trailing colored smoke, then bursts with an effect based on its color. */
public class FlareEntity extends ThrowableItemProjectile {
    private static final EntityDataAccessor<Integer> COLOR =
            SynchedEntityData.defineId(FlareEntity.class, EntityDataSerializers.INT);
    private int life;

    public FlareEntity(EntityType<? extends FlareEntity> type, Level level) { super(type, level); }

    public FlareEntity(Level level, LivingEntity shooter, FlareColor color) {
        super(ModEntities.FLARE.get(), shooter, level);
        entityData.set(COLOR, color.ordinal());
        setItem(new ItemStack(color.item()));
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(COLOR, 0);
    }

    public FlareColor color() { return FlareColor.byIndex(entityData.get(COLOR)); }

    @Override protected Item getDefaultItem() { return ModItems.GREEN_FLARE.get(); }
    @Override protected double getDefaultGravity() { return 0.01; }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            FlareColor c = color();
            level().addParticle(new DustParticleOptions(new Vector3f(c.r, c.g, c.b), 2.5f), getX(), getY(), getZ(), 0, 0, 0);
            if (tickCount % 2 == 0) level().addParticle(ParticleTypes.SMOKE, getX(), getY(), getZ(), 0, 0.02, 0);
        } else if (++life >= 35) {
            burst();
        }
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (!level().isClientSide) burst();
    }

    private void burst() {
        if (isRemoved() || !(level() instanceof ServerLevel sl)) return;
        FlareColor c = color();
        playSound(SoundEvents.FIREWORK_ROCKET_BLAST, 4.0f, 0.8f);
        sl.sendParticles(new DustParticleOptions(new Vector3f(c.r, c.g, c.b), 4.0f),
                getX(), getY(), getZ(), 120, 2.0, 2.0, 2.0, 0.0);

        Player owner = getOwner() instanceof Player p ? p : null;
        switch (c) {
            case GREEN -> {
                List<GiantEntity> giants = sl.getEntitiesOfClass(GiantEntity.class, getBoundingBox().inflate(128));
                for (GiantEntity g : giants) g.addEffect(new MobEffectInstance(MobEffects.GLOWING, 400));
                if (owner != null) owner.displayClientMessage(
                        Component.translatable("message.giantslayer.flare_green", giants.size()), true);
            }
            case RED -> {
                int gx = (int) getX(), gz = (int) getZ();
                int gy = sl.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, gx, gz);
                for (GiantEntity g : sl.getEntitiesOfClass(GiantEntity.class, getBoundingBox().inflate(96))) {
                    g.distract(140);
                    g.getNavigation().moveTo(gx + 0.5, gy, gz + 0.5, 1.0);
                }
            }
            case BLACK -> {
                sl.sendParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE, getX(), getY(), getZ(), 150, 5.0, 3.0, 5.0, 0.01);
                for (GiantEntity g : sl.getEntitiesOfClass(GiantEntity.class, getBoundingBox().inflate(40))) {
                    g.distract(160);
                    g.getNavigation().stop();
                }
            }
        }
        discard();
    }
}
