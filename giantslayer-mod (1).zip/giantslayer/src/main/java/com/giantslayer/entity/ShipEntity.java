package com.giantslayer.entity;

import com.giantslayer.entity.projectile.CannonballEntity;
import com.giantslayer.registry.ModItems;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.vehicle.Boat;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * A small sailing ship: seats 4 (first to board steers), much faster than a boat,
 * and the pilot can fire broadsides (key B) using cannonballs from their inventory.
 */
public class ShipEntity extends Boat {
    private static final double[][] SEATS = {{0.0, -1.3}, {0.5, 0.0}, {-0.5, 0.0}, {0.0, 1.2}};

    public ShipEntity(EntityType<? extends Boat> type, Level level) {
        super(type, level);
    }

    @Override public Item getDropItem() { return ModItems.SHIP.get(); }

    @Override
    protected boolean canAddPassenger(Entity passenger) {
        return getPassengers().size() < 4 && !isEyeInFluid(FluidTags.WATER);
    }

    @Override
    protected Vec3 getPassengerAttachmentPoint(Entity passenger, EntityDimensions dims, float partialTick) {
        int i = Math.max(0, Math.min(3, getPassengers().indexOf(passenger)));
        return new Vec3(SEATS[i][0], 0.5, SEATS[i][1]).yRot(-getYRot() * Mth.DEG_TO_RAD);
    }

    @Override
    public void tick() {
        super.tick();
        // Sails: extra thrust when the pilot pushes forward.
        if (isControlledByLocalInstance() && getControllingPassenger() instanceof Player p && p.zza > 0 && isInWater()) {
            Vec3 fwd = Vec3.directionFromRotation(0, getYRot());
            Vec3 v = getDeltaMovement().add(fwd.scale(0.025));
            double h = Math.sqrt(v.x * v.x + v.z * v.z);
            if (h > 0.9) v = new Vec3(v.x / h * 0.9, v.y, v.z / h * 0.9);
            setDeltaMovement(v);
        }
    }

    /** Called from the B-key payload. Fires one cannonball from each side. */
    public static void fireBroadside(ServerPlayer sp) {
        if (!(sp.getVehicle() instanceof ShipEntity ship)) {
            sp.displayClientMessage(Component.translatable("message.giantslayer.not_on_ship"), true);
            return;
        }
        Item ball = ModItems.CANNONBALL.get();
        if (sp.getCooldowns().isOnCooldown(ball)) return;
        if (!sp.getAbilities().instabuild && !takeItems(sp, ball, 2)) {
            sp.displayClientMessage(Component.translatable("message.giantslayer.need_cannonballs"), true);
            return;
        }
        ServerLevel sl = sp.serverLevel();
        Vec3 fwd = Vec3.directionFromRotation(0, ship.getYRot());
        for (int side = -1; side <= 1; side += 2) {
            Vec3 dir = new Vec3(fwd.z * side, 0.12, -fwd.x * side).normalize();
            Vec3 at = ship.position().add(dir.scale(2.2)).add(0, 1.0, 0);
            CannonballEntity cb = new CannonballEntity(sl, at.x, at.y, at.z);
            cb.setOwner(sp);
            cb.shoot(dir.x, dir.y, dir.z, 3.0f, 1.0f);
            sl.addFreshEntity(cb);
            sl.sendParticles(ParticleTypes.LARGE_SMOKE, at.x, at.y, at.z, 12, 0.3, 0.3, 0.3, 0.05);
        }
        sl.playSound(null, ship.blockPosition(), SoundEvents.GENERIC_EXPLODE.value(), SoundSource.PLAYERS, 2.0f, 1.2f);
        sp.getCooldowns().addCooldown(ball, 40);
    }

    private static boolean takeItems(Player p, Item item, int count) {
        int have = 0;
        for (ItemStack s : p.getInventory().items) if (s.is(item)) have += s.getCount();
        if (have < count) return false;
        for (ItemStack s : p.getInventory().items) {
            if (count <= 0) break;
            if (s.is(item)) { int take = Math.min(count, s.getCount()); s.shrink(take); count -= take; }
        }
        return true;
    }
}
