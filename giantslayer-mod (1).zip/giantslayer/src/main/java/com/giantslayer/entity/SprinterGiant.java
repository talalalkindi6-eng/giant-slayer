package com.giantslayer.entity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;

/** Lanky and frail, but runs down anything on foot. Never outrun one — outfly it. */
public class SprinterGiant extends GiantEntity {
    public SprinterGiant(EntityType<? extends Monster> type, Level level) { super(type, level); }

    public static AttributeSupplier.Builder createAttributes() {
        return GiantEntity.createAttributes().add(Attributes.MOVEMENT_SPEED, 0.36);
    }

    @Override protected double minScale() { return 1.4; }
    @Override protected double maxScale() { return 2.6; }
    @Override protected double healthPerScale() { return 35.0; }
    @Override protected double damagePerScale() { return 4.0; }
    @Override public float getVoicePitch() { return 0.7f; }
}
